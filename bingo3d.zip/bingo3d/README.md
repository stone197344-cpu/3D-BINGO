# Lucky Lounge Bingo — 3D Jazz Club Bingo

A Microsoft-Bingo-style game, staged as a full 3D jazz lounge. The room is modelled
geometry, the flashboard is a real LED-style panel, and every sound — chips, the cage,
applause, the caller's voice — is generated live. **There is no background music.**

## Play it

| | |
|---|---|
| **Single file (easiest)** | `LuckyLoungeBingo.html` — double-click it. Works offline, no server, no installs. |
| **Dev version** | `index.html` + `src/` — served over HTTP: `npm start` (Python's http.server on :8123). |

Sound needs one click on the page (browser policy), so press **ENTER THE LOUNGE**
and the room comes to life.

![The lounge at play](shots/gameplay.jpg)

## How the game plays

* The caller spins the brass cage, a ball rolls down the chute, and the number
  lights up on the giant flashboard **and** on the tray of the ten most recent calls.
* Click the matching square on **your card** to daub a chip. Called squares glow
  gold; miss your window and the call is gone.
* Complete the round's pattern and the **BINGO!** lamp lights — claim before one of
  the four regulars (Rosa, Marty, Duke, Lena) gets there first. A false claim costs
  you 75 bucks; every chip earns 5.
* Ten-round ladder: Any Line → Four Corners → The X → Postage Stamp → Around the
  Free → Any Line → Blackout. Pots grow, and the caller speeds up as your card fills.
* The **Shop** sells power-ups: Auto-daub, Slow Sip (slower caller, bought with the
  drink), and Lucky Star (a square daubs itself).

| Keys | |
|---|---|
| <kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> <kbd>4</kbd> | Wide room · Card close-up · Cage · Flashboard |
| drag / scroll | orbit the camera / lean in |
| click | daub a called square |
| <kbd>F</kbd> | daub every square that is currently available |
| <kbd>A</kbd> | toggle auto-daub |
| <kbd>V</kbd> | caller voice on/off |
| <kbd>Enter</kbd> | claim BINGO |

## Sound (no music)

`src/audio.js` holds three small engines, all synthesized — there are no audio files
anywhere in the build:

* **Sfx** — the chip landing on card stock, the cage crank, the ball rolling the chute
  and dropping into the tray, UI blips, the payout chime, a crowd's applause with
  whoops, and the win sting. Exposed as `sfx.chip()`, `sfx.cageCrank()`, `sfx.applause()`,
  `sfx.fanfare()`, `sfx.coin()` and friends.
* **Ambience** — the room itself: a low crowd murmur with slow swells, glass clinks on
  the bar rail, a chair scraping the parquet, a few syllables of half-heard chatter
  (filtered like voices two tables away). Quiet enough that you only notice it when it
  stops.
* **Caller** — reads each ball aloud ("B… seven!") through the device's speech engine.
  Toggle it in the top bar or with <kbd>V</kbd>. If no speech voice exists the game
  stays silent for calls and nothing else changes.

The **SFX** and **Caller** buttons in the top bar control the two audible systems
independently.

## The room

* Bar with mirror, bottle shelves, stool row and a shaking-cocktail bartender
* Bandstand: grand piano with propped lid, upright bass, brushed drum kit — the three
  players are still animated (hands on the keys, bassist plucking, brushes swinging)
  as silent stage dressing
* Audience of tables with candle glow, wall sconces, three brass chandeliers
* Brass bingo cage with tumbling balls, chute, ten-ball tray, ball cradle, marquee bulbs
* 9.4 m self-lit LED flashboard with the 75-number wall and live player standings
* Dust motes, velvet walls, art-deco posters, night-city windows, camera breathing

Every texture (wood, felt, velvet, card stock, ball atlas, rug, posters, city, LED panel)
is painted procedurally onto a canvas at load — that's why the single file is offline.

## Running from source

```bash
cd bingo3d
python3 -m http.server 8123      # then open http://localhost:8123/
```

Rebuild the single file after editing `src/`:

```bash
node build.js                    # writes LuckyLoungeBingo.html
```

### Performance

`?q=low`, `?q=med` or `?q=high` force a quality tier (pixel ratio, shadows, dust).
By default the game watches its own frame rate and steps quality down once if the
device can't hold ~24 fps, so weak laptops and phones still play.

### Dev tools (`tools/`)

Eight small scripts, each covering a different surface. `npm i` first (puppeteer is
the only dev dependency).

| Script | What it checks |
|---|---|
| `tools/audio-node.js` | runs the SFX / ambience / caller through a stub Web Audio API — no browser needed |
| `tools/smoke.js` | boots the single-file build, plays a round, asserts no music engine remains |
| `tools/preview-check.js` | same, but against the dev server root (`index.html` + `src/`) |
| `tools/interact.js` | a real mouse click lays a chip; a click on an uncalled number is rejected |
| `tools/paths.js` | opponent win, false claim, and the full ten-round pattern ladder |
| `tools/audiotest.js` | taps the audio bus in Chrome and measures peak/RMS |
| `tools/perf.js` | counts lights/meshes/draw calls and measures frame time |
| `tools/mobile.js` | 390×844 portrait layout |

Run them with the server up (`npm start`), e.g. `npm run smoke`. Each writes its
screenshots into `shots/`, which it creates if missing.

`shots/` holds reference screenshots.
