/* ============================================================================
   audio.js — Sound effects, room ambience and the bingo caller voice.
   (The synthesized jazz-trio music engine has been removed entirely, at the
   user's request. Nothing in this file plays background music; every sound
   here is a discrete event effect or room tone.)
     • Sfx      : chips, ball roll/drop, cage crank, UI blips, coin payout,
                  applause and the win sting.
     • Ambience : low crowd murmur, glass clinks, chair scrapes, distant chatter.
     • Caller   : reads the balls aloud through the system speech engine.
   ========================================================================== */

/* ==================================================================== Sound FX */
class Sfx {
  constructor(ctx, out) {
    this.ctx = ctx;
    this.out = out;
    this.bus = ctx.createGain(); this.bus.gain.value = 0.9;
    this.rev = ctx.createConvolver(); this.rev.buffer = this._ir();
    this.revG = ctx.createGain(); this.revG.gain.value = 0.35;
    this.bus.connect(this.out); this.bus.connect(this.rev); this.rev.connect(this.revG); this.revG.connect(this.out);
    const nb = ctx.createBuffer(1, ctx.sampleRate * 1.5, ctx.sampleRate);
    const d = nb.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this.noise = nb;
  }
  _ir() {
    const ctx = this.ctx, sr = ctx.sampleRate, n = Math.floor(sr * 1.6);
    const b = ctx.createBuffer(2, n, sr);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c);
      let lp = 0;
      for (let i = 0; i < n; i++) {
        const t = i / n;
        lp += ((Math.random() * 2 - 1) - lp) * 0.5;
        d[i] = lp * Math.pow(1 - t, 3.2) * 0.6;
      }
    }
    return b;
  }
  _n(when, dur, type, freq, q, gain, pan) {
    const ctx = this.ctx, src = ctx.createBufferSource();
    src.buffer = this.noise; src.loop = true;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q || 1;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(gain, when + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0005, when + dur);
    const p = ctx.createStereoPanner(); p.pan.value = pan || 0;
    src.connect(f); f.connect(g); g.connect(p); p.connect(this.bus);
    src.start(when); src.stop(when + dur + 0.05);
  }
  _tone(when, dur, f0, f1, gain, type, pan) {
    const ctx = this.ctx, o = ctx.createOscillator();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, when);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), when + dur * 0.9);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(gain, when + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0004, when + dur);
    const p = ctx.createStereoPanner(); p.pan.value = pan || 0;
    o.connect(g); g.connect(p); p.connect(this.bus);
    o.start(when); o.stop(when + dur + 0.03);
  }
  chip(when, pan) {                       // placing a daub chip on the card
    const w = when || this.ctx.currentTime;
    this._n(w, 0.045, 'bandpass', 2600, 1.4, 0.22, pan || 0);
    this._tone(w, 0.07, 900, 420, 0.10, 'triangle', pan || 0);
    this._n(w + 0.012, 0.05, 'highpass', 5200, 0.8, 0.07, pan || 0);
  }
  ballRoll(when, dur) {
    const w = when || this.ctx.currentTime, d = dur || 0.55;
    this._n(w, d, 'bandpass', 1500, 1.6, 0.09, 0.15);
    this._tone(w, d, 320, 260, 0.03, 'triangle', 0.1);
  }
  ballDrop(when) {
    const w = when || this.ctx.currentTime;
    this._tone(w, 0.20, 420, 160, 0.22, 'sine', 0.05);
    this._n(w, 0.09, 'bandpass', 2200, 1.2, 0.16, 0.1);
    this._n(w + 0.10, 0.06, 'bandpass', 3200, 1.5, 0.06, -0.2);
  }
  cageCrank(when, count, step) {
    const w0 = when || this.ctx.currentTime;
    for (let i = 0; i < (count || 8); i++) {
      const w = w0 + i * (step || 0.055);
      this._n(w, 0.03, 'bandpass', 3200 + Math.random() * 900, 3.5, 0.10, -0.05);
      this._n(w, 0.05, 'bandpass', 620, 2.0, 0.06, -0.1);
    }
  }
  ui(kind) {
    const w = this.ctx.currentTime + 0.005;
    if (kind === 'hover') this._n(w, 0.03, 'highpass', 6000, 0.7, 0.03);
    else if (kind === 'click') { this._tone(w, 0.06, 1400, 900, 0.09, 'triangle'); this._n(w, 0.03, 'highpass', 4000, 0.8, 0.05); }
    else if (kind === 'bad') { this._tone(w, 0.3, 300, 150, 0.14, 'sawtooth', 0); }
    else this._tone(w, 0.12, 880, 1320, 0.1, 'triangle');
  }
  coin() {
    const w = this.ctx.currentTime;
    for (let i = 0; i < 7; i++) {
      const t = w + i * 0.055 + Math.random() * 0.02;
      this._tone(t, 0.30, 1180 + Math.random() * 700, null, 0.055, 'triangle', (Math.random() - 0.5) * 0.8);
      this._tone(t + 0.004, 0.24, 2400 + Math.random() * 900, null, 0.03, 'sine', (Math.random() - 0.5) * 0.8);
    }
  }
  applause(intensity, dur) {
    const ctx = this.ctx, w = ctx.currentTime, d = dur || 3.2, I = intensity || 1;
    const src = ctx.createBufferSource();
    src.buffer = this.noise; src.loop = true;
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 700;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2600; bp.Q.value = 0.6;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, w);
    g.gain.linearRampToValueAtTime(0.16 * I, w + 0.25);
    g.gain.setValueAtTime(0.16 * I, w + d * 0.45);
    g.gain.exponentialRampToValueAtTime(0.001, w + d);
    // clap grain
    const grain = ctx.createGain(); grain.gain.value = 1;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 11 + Math.random() * 4;
    const lg = ctx.createGain(); lg.gain.value = 0.5;
    lfo.connect(lg); lg.connect(grain.gain);
    const pan = ctx.createStereoPanner(); pan.pan.value = 0.25;
    src.connect(hp); hp.connect(bp); bp.connect(grain); grain.connect(g); g.connect(pan); pan.connect(this.bus);
    src.start(w); src.stop(w + d + 0.1);
    lfo.start(w); lfo.stop(w + d + 0.1);
    // whoops
    for (let i = 0; i < 3; i++) {
      const t = w + 0.3 + Math.random() * d * 0.6;
      this._tone(t, 0.35, 520 + Math.random() * 420, 700 + Math.random() * 500, 0.035, 'sawtooth', (Math.random() - 0.5) * 1.4);
    }
  }
  fanfare(win) {
    const ctx = this.ctx, w = ctx.currentTime + 0.02;
    const seq = win ? [[0, 0], [0.12, 4], [0.24, 7], [0.36, 12], [0.52, 16]] : [[0, 0], [0.16, 3], [0.38, 5]];
    seq.forEach(([t, semi]) => {
      const f = 523.25 * Math.pow(2, semi / 12);
      this._tone(w + t, win ? 1.1 : 1.4, f, null, 0.09, 'triangle', -0.15);
      this._tone(w + t, win ? 1.0 : 1.3, f * 2, null, 0.045, 'sine', 0.2);
      this._tone(w + t, win ? 0.9 : 1.2, f * 3.01, null, 0.02, 'sine', 0.3);
    });
    this._n(w, 1.2, 'highpass', 5000, 0.8, win ? 0.06 : 0.03, 0);
  }
}

/* =============================================================== Ambience ==== */
/* Room tone for a packed lounge: a low crowd murmur, the occasional glass
   clink on the bar rail, a chair scrape and a thread of distant chatter.
   Very low level — you should only notice it when it stops. */
class Ambience {
  constructor(ctx, out) {
    this.ctx = ctx;
    this.out = out;
    this.bus = ctx.createGain();
    this.bus.gain.value = 0;
    this.bus.connect(out);
    this.playing = false;
    // murmur bed
    const N = ctx.sampleRate * 3;
    const nb = ctx.createBuffer(1, N, ctx.sampleRate);
    const d = nb.getChannelData(0);
    let lp = 0;
    for (let i = 0; i < N; i++) {
      const white = Math.random() * 2 - 1;
      lp += (white - lp) * 0.28;
      // slow rises and falls, like a room full of half-heard conversation
      const swell = 0.55 + 0.45 * Math.sin(i / ctx.sampleRate * 0.7) * Math.sin(i / ctx.sampleRate * 0.23 + 1.3);
      d[i] = lp * swell * 0.5;
    }
    const src = ctx.createBufferSource();
    src.buffer = nb; src.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 620; bp.Q.value = 0.55;
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 180;
    const mg = ctx.createGain(); mg.gain.value = 0.16;
    // two slow LFOs so the murmur never sits still
    const l1 = ctx.createOscillator(); l1.frequency.value = 0.13;
    const l1g = ctx.createGain(); l1g.gain.value = 0.06;
    const l2 = ctx.createOscillator(); l2.frequency.value = 0.047;
    const l2g = ctx.createGain(); l2g.gain.value = 0.05;
    l1.connect(l1g); l1g.connect(mg.gain);
    l2.connect(l2g); l2g.connect(mg.gain);
    src.connect(hp); hp.connect(bp); bp.connect(mg); mg.connect(this.bus);
    this.murmur = src; this.murmurGain = mg;
    this.lfos = [l1, l2];
    this.noise = nb;
    src.start(0); l1.start(0); l2.start(0);
  }
  start() {
    if (this.playing) return;
    this.playing = true;
    const t = this.ctx.currentTime;
    this.bus.gain.cancelScheduledValues(t);
    this.bus.gain.setValueAtTime(0.0001, t);
    this.bus.gain.linearRampToValueAtTime(0.5, t + 4);
    this._schedule();
  }
  stop() {
    if (!this.playing) return;
    this.playing = false;
    clearTimeout(this.timer);
    const t = this.ctx.currentTime;
    this.bus.gain.cancelScheduledValues(t);
    this.bus.gain.setTargetAtTime(0, t, 0.6);
  }
  _schedule() {
    if (!this.playing) return;
    const wait = 4000 + Math.random() * 9000;
    this.timer = setTimeout(() => {
      if (!this.playing) return;
      const r = Math.random();
      if (r < 0.45) this.clink();
      else if (r < 0.75) this.chatter();
      else this.scrape();
      this._schedule();
    }, wait);
  }
  clink() {
    const t = this.ctx.currentTime + Math.random() * 0.4;
    const pan = (Math.random() - 0.5) * 1.6;
    const n = 1 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) {
      const f = 1750 + Math.random() * 1500;
      const o = this.ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
      const o2 = this.ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2.76;
      const g = this.ctx.createGain();
      const t0 = t + i * (0.045 + Math.random() * 0.14);
      g.gain.setValueAtTime(0, t0);
      g.gain.linearRampToValueAtTime(0.012 + Math.random() * 0.010, t0 + 0.003);
      g.gain.exponentialRampToValueAtTime(0.0002, t0 + 0.22 + Math.random() * 0.3);
      const p = this.ctx.createStereoPanner(); p.pan.value = pan;
      const o2g = this.ctx.createGain(); o2g.gain.value = 0.35;
      o.connect(g); o2.connect(o2g); o2g.connect(g); g.connect(p); p.connect(this.bus);
      o.start(t0); o.stop(t0 + 0.7); o2.start(t0); o2.stop(t0 + 0.7);
    }
  }
  chatter() {
    // a few syllables of half-heard conversation, filtered like distant voices
    const t = this.ctx.currentTime;
    const pan = (Math.random() - 0.5) * 1.5;
    const p = this.ctx.createStereoPanner(); p.pan.value = pan;
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 420 + Math.random() * 500; bp.Q.value = 1.4;
    bp.connect(p); p.connect(this.bus);
    const base = 105 + Math.random() * 70;
    let pos = 0;
    const syl = 3 + Math.floor(Math.random() * 4);
    for (let i = 0; i < syl; i++) {
      const dur = 0.10 + Math.random() * 0.13;
      const o = this.ctx.createOscillator(); o.type = 'sawtooth';
      const f0 = base * (0.86 + Math.random() * 0.4);
      o.frequency.setValueAtTime(f0, t + pos);
      o.frequency.linearRampToValueAtTime(f0 * (0.9 + Math.random() * 0.25), t + pos + dur);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0, t + pos);
      g.gain.linearRampToValueAtTime(0.016 + Math.random() * 0.012, t + pos + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0004, t + pos + dur);
      o.connect(g); g.connect(bp);
      o.start(t + pos); o.stop(t + pos + dur + 0.05);
      pos += dur + 0.03 + Math.random() * 0.08;
    }
  }
  scrape() {
    // a chair shifting on the parquet
    const t = this.ctx.currentTime + Math.random() * 0.3;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise; src.loop = true;
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 700 + Math.random() * 500; bp.Q.value = 1.1;
    const g = this.ctx.createGain();
    const dur = 0.28 + Math.random() * 0.24;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.020, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0004, t + dur);
    const p = this.ctx.createStereoPanner(); p.pan.value = (Math.random() - 0.5) * 1.7;
    src.connect(bp); bp.connect(g); g.connect(p); p.connect(this.bus);
    src.start(t); src.stop(t + dur + 0.05);
  }
}

/* ============================================================ Caller (voice) == */
class Caller {
  constructor() {
    this.enabled = true;
    this.voice = null;
    this.ready = false;
    this.supported = typeof window !== 'undefined' && 'speechSynthesis' in window;
    if (this.supported) {
      const pick = () => {
        try {
          const vs = window.speechSynthesis.getVoices() || [];
          this.voice = vs.find((v) => /en[-_]US/i.test(v.lang) && /female|samantha|zira|aria|jenny|ava/i.test(v.name))
            || vs.find((v) => /en[-_]US/i.test(v.lang)) || vs.find((v) => /^en/i.test(v.lang)) || null;
          this.ready = true;
        } catch (e) { this.ready = true; }
      };
      pick();
      try { window.speechSynthesis.onvoiceschanged = pick; } catch (e) {}
    }
  }
  say(text, opts) {
    if (!this.enabled || !this.supported) return false;
    try {
      const u = new SpeechSynthesisUtterance(text);
      if (this.voice) u.voice = this.voice;
      u.rate = (opts && opts.rate) || 1.0;
      u.pitch = (opts && opts.pitch) || 1.05;
      u.volume = 1.0;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
      return true;
    } catch (e) { return false; }
  }
  callNumber(letter, num) {
    const words = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
      'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy'];
    let n;
    if (num < 20) n = words[num];
    else {
      const t = Math.floor(num / 10), o = num % 10;
      n = tens[t] + (o ? ' ' + words[o] : '');
    }
    const letterWord = { B: 'B', I: 'I', N: 'N', G: 'G', O: 'O' }[letter];
    return this.say(letterWord + '. ... ' + n + '!', { pitch: 1.1, rate: 0.98 });
  }
  stop() { if (this.supported) { try { window.speechSynthesis.cancel(); } catch (e) {} } }
}
