/* ============================================================================
   main.js — Lucky Lounge Bingo: game logic, 3D card rig, camera direction
   ========================================================================== */

const CARD_W = 1.05, CARD_H = 1.40;
const TEXW = 1024, TEXH = 1360;
const G = { x0: 44, xw: 936, y0: 192, yh: 1108 };      // card grid box, in canvas px
const LETTERS = ['B', 'I', 'N', 'G', 'O'];
// storage that never throws (sandboxed iframes block localStorage)
const Store = {
  get(key, dflt) { try { const v = localStorage.getItem(key); return v === null ? dflt : v; } catch (e) { return dflt; } },
  set(key, val) { try { localStorage.setItem(key, String(val)); } catch (e) {} }
};
const letterOf = (n) => LETTERS[Math.floor((n - 1) / 15)];

/* ------------------------------------------------------------- patterns --- */
const LINES = (() => {
  const out = [];
  for (let r = 0; r < 5; r++) out.push(Array.from({ length: 5 }, (_, c) => [r, c]));
  for (let c = 0; c < 5; c++) out.push(Array.from({ length: 5 }, (_, r) => [r, c]));
  out.push([[0, 0], [1, 1], [2, 2], [3, 3], [4, 4]]);
  out.push([[0, 4], [1, 3], [2, 2], [3, 1], [4, 0]]);
  return out;
})();
const STAMPS = (() => {
  const out = [];
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) out.push([[r, c], [r + 1, c], [r, c + 1], [r + 1, c + 1]]);
  return out;
})();
const ALLCELLS = (() => { const o = []; for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) o.push([r, c]); return o; })();

const PATTERNS = {
  anyline: {
    name: 'Any Line', desc: 'Cover a whole row, column or diagonal.',
    groups: LINES, diagram: [[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]]
  },
  corners: {
    name: 'Four Corners', desc: 'Cover the four corners of the card.',
    groups: [[[0, 0], [0, 4], [4, 0], [4, 4]]]
  },
  thex: {
    name: 'The X', desc: 'Cover both diagonals.',
    groups: [[[0, 0], [1, 1], [2, 2], [3, 3], [4, 4]], [[0, 4], [1, 3], [2, 2], [3, 1], [4, 0]]]
  },
  stamp: {
    name: 'Postage Stamp', desc: 'Cover any 2 × 2 block of squares.',
    groups: STAMPS
  },
  around: {
    name: 'Around the Free', desc: 'Cover the eight squares ringing the free space.',
    groups: [[[1, 1], [1, 2], [1, 3], [2, 1], [2, 3], [3, 1], [3, 2], [3, 3]]]
  },
  blackout: {
    name: 'Blackout', desc: 'Cover every single square. Long game, giant pot.',
    groups: [ALLCELLS]
  }
};
const ROUND_PLAN = ['anyline', 'anyline', 'corners', 'thex', 'stamp', 'around', 'anyline', 'blackout', 'thex', 'blackout'];

const k = (r, c) => r * 5 + c;
const progOf = (daubed, groups) => {
  let best = 0, done = false, target = null;
  groups.forEach((gr) => {
    const hit = gr.filter(([r, c]) => daubed.has(k(r, c))).length;
    const frac = hit / gr.length;
    if (frac > best) { best = frac; target = gr; }
    if (hit === gr.length) done = true;
  });
  return { best, done, target };
};

function makeCard(id) {
  const ranges = [[1, 15], [16, 30], [31, 45], [46, 60], [61, 75]];
  const grid = Array.from({ length: 5 }, () => new Array(5).fill(0));
  for (let c = 0; c < 5; c++) {
    const pool = [];
    for (let n = ranges[c][0]; n <= ranges[c][1]; n++) pool.push(n);
    for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    for (let r = 0; r < 5; r++) grid[r][c] = pool[r];
  }
  grid[2][2] = 0;
  return { id, grid, serial: 100000 + Math.floor(Math.random() * 899999) };
}

/* ============================================================ the card rig == */
class CardRig {
  constructor(lounge, card) {
    this.lounge = lounge;
    this.card = card;
    this.group = new THREE.Group();
    this.chips = new Map();
    this.rings = new Map();
    this.tweens = [];

    // cardboard body: printed face on the +Z side, cream edges like real stock
    const tex = new THREE.CanvasTexture(Tex.cardFace(card));
    tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
    const faceMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.62, metalness: 0.0, envMapIntensity: 0.55 });
    const edgeMat = new THREE.MeshStandardMaterial({ color: 0xe6dcc4, roughness: 0.85 });
    const geo = new THREE.BoxGeometry(CARD_W, CARD_H, 0.012);
    this.cardMesh = new THREE.Mesh(geo, [edgeMat, edgeMat, edgeMat, edgeMat, faceMat, edgeMat]);
    this.cardMesh.userData.isCard = true;
    this.cardMesh.castShadow = true;
    this.group.add(this.cardMesh);
    this.group.scale.setScalar(0.86);
    faceMat.emissive = new THREE.Color(0xffffff);
    faceMat.emissiveMap = tex;
    faceMat.emissiveIntensity = 0.20;      // the lectern lamp keeps the card readable

    const chipCanvas = [];
    const chipColors = { 0: '#c9a227', 1: '#2f6fb5', 2: '#b8232f', 3: '#2e9e58' };
    for (let i = 0; i < 4; i++) chipCanvas.push(new THREE.CanvasTexture(Tex.chip(chipColors[i])));
    this.chipMats = chipCanvas.map((t) => {
      t.colorSpace = THREE.SRGBColorSpace;
      return new THREE.MeshStandardMaterial({ map: t, roughness: 0.35, metalness: 0.05, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 0.18 });
    });
    this.chipGeo = new THREE.CylinderGeometry(0.062, 0.064, 0.014, 26);
    this.chipGeo.rotateX(Math.PI / 2);
    this.ringGeo = new THREE.TorusGeometry(0.068, 0.006, 8, 26);

    // the free space is permanently daubed
    this.daubed = new Set([k(2, 2)]);
    this.dropChip(2, 2, false);
    lounge.cardStand.add(this.group);
    this.group.position.set(0, 0.50, 0.036);
  }

  cellLocal(row, col) {
    const u = (G.x0 + G.xw * (col + 0.5) / 5) / TEXW;
    const vC = (G.y0 + G.yh * (row + 0.5) / 5) / TEXH;
    return new THREE.Vector3((u - 0.5) * CARD_W, (0.5 - vC) * CARD_H, 0.019);
  }
  pickFromUV(uv) {
    const u = uv.x, vC = 1 - uv.y;
    const col = Math.floor(((u * TEXW - G.x0) / G.xw) * 5);
    const row = Math.floor(((vC * TEXH - G.y0) / G.yh) * 5);
    if (row < 0 || row > 4 || col < 0 || col > 4) return null;
    return { row, col };
  }
  numAt(row, col) { return this.card.grid[row][col]; }
  cellOf(num) {
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) if (this.card.grid[r][c] === num) return { row: r, col: c };
    return null;
  }

  dropChip(row, col, animate, colorIdx) {
    const key = k(row, col);
    let chip = this.chips.get(key);
    const p = this.cellLocal(row, col);
    if (!chip) {
      chip = new THREE.Mesh(this.chipGeo, this.chipMats[colorIdx === undefined ? (key % 4) : colorIdx]);
      chip.castShadow = true;
      chip.rotation.z = Math.random() * Math.PI;
      this.group.add(chip);
      this.chips.set(key, chip);
      chip.position.copy(p);
      if (animate) {
        chip.position.y = p.y + 0.30; chip.position.z = p.z + 0.22;
        chip.scale.setScalar(0.6);
        this.tweens.push({
          start: (this.now === undefined ? 0 : this.now), dur: 0.36, obj: chip,
          from: { y: chip.position.y, z: chip.position.z, s: 0.6 },
          to: { y: p.y, z: p.z, s: 1 }
        });
      }
    }
    this.daubed.add(key);
    this.setHighlight(row, col, false);
    return chip;
  }
  setHighlight(row, col, on) {
    const key = k(row, col);
    let ring = this.rings.get(key);
    if (on && !ring) {
      ring = new THREE.Mesh(this.ringGeo, new THREE.MeshBasicMaterial({
        color: 0xffd76a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false
      }));
      ring.userData.pulse = Math.random() * Math.PI * 2;
      this.group.add(ring);
      const p = this.cellLocal(row, col);
      ring.position.copy(p);
      ring.position.z += 0.004;
      this.rings.set(key, ring);
    } else if (!on && ring) {
      this.group.remove(ring);
      ring.material.dispose();
      this.rings.delete(key);
    }
  }
  clearHighlights() { Array.from(this.rings.keys()).forEach((key) => this.setHighlight(Math.floor(key / 5), key % 5, false)); }
  shake() { this.shakeT = 0.5; }
  update(dt, t, wt) {
    this.now = wt;
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      const p = Math.min(1, (wt - tw.start) / tw.dur);
      const e = 1 - Math.pow(1 - p, 3);
      const bob = Math.sin(p * Math.PI) * 0.06;
      tw.obj.position.y = tw.from.y + (tw.to.y - tw.from.y) * e + bob;
      tw.obj.position.z = tw.from.z + (tw.to.z - tw.from.z) * e;
      tw.obj.scale.setScalar(tw.from.s + (tw.to.s - tw.from.s) * e);
      if (p >= 1) this.tweens.splice(i, 1);
    }
    this.rings.forEach((ring) => {
      const s = 1 + Math.sin(t * 5 + ring.userData.pulse) * 0.14;
      ring.scale.setScalar(s);
      ring.material.opacity = 0.55 + 0.45 * Math.abs(Math.sin(t * 3.4 + ring.userData.pulse));
    });
    if (this.shakeT > 0) {
      this.shakeT -= dt;
      const a = Math.max(0, this.shakeT) * 0.09;
      this.group.position.x = Math.sin(t * 60) * a;
    } else if (this.shakeT !== -1) { this.shakeT = -1; this.group.position.x = 0; }
  }
}

/* ============================================================ the camera ==== */
const PRESETS = {
  table: { pos: [0.45, 2.44, 7.90], target: [-0.15, 1.86, -2.2], fov: 49 },
  cage: { pos: [-0.30, 3.02, 2.15], target: [-1.00, 2.32, -0.45], fov: 46 },
  screen: { pos: [0.40, 2.60, -4.60], target: [0.40, 3.35, -11.30], fov: 50 },
  celebrate: { pos: [0, 2.6, 6.0], target: [0, 1.6, -1.0], fov: 52 }
};
class CameraRig {
  constructor(camera) {
    this.cam = camera;
    this.cardAnchor = null;      // set by the game: { pos, look, fov, up }
    this.pos = new THREE.Vector3(...PRESETS.table.pos);
    this.tgt = new THREE.Vector3(...PRESETS.table.target);
    this.yaw = 0; this.pitch = 0; this.zoom = 1;
    this.preset = 'table';
    this.orbitT = 0;
    this.fov = PRESETS.table.fov;
  }
  setPreset(name) {
    if (name === 'celebrate') { this.orbitT = 0; }
    this.preset = name;
  }
  update(dt, t) {
    const aspect = this.cam.aspect || 1.78;
    let P = PRESETS[this.preset] || PRESETS.table;
    let pPos = new THREE.Vector3(...(P ? P.pos : PRESETS.table.pos));
    let pTgt = new THREE.Vector3(...(P ? P.target : PRESETS.table.target));
    let fov = P ? P.fov : 50;
    let wantUp = null;
    if (this.preset === 'card' && this.cardAnchor) {
      pPos = this.cardAnchor.pos.clone();
      pTgt = this.cardAnchor.look.clone();
      wantUp = this.cardAnchor.up.clone();
      fov = this.cardAnchor.fov;
    }
    if (this.preset === 'celebrate') {
      this.orbitT += dt * 0.30;
      const a = Math.sin(this.orbitT * 0.5) * 0.9;
      pPos.set(Math.sin(a) * 6.4, 2.4 + Math.sin(this.orbitT * 0.7) * 0.5, 2.6 + Math.cos(a) * 3.6);
      pTgt.set(0, 1.5, -0.6);
      fov = 52;
    }
    // portrait / narrow windows: step back and widen
    const narrow = Math.max(0, 1.35 - aspect);
    if (narrow > 0) {
      fov *= 1 + narrow * 0.55;
      const off = pPos.clone().sub(pTgt).multiplyScalar(1 + narrow * 0.7);
      pPos.copy(pTgt).add(off);
    }
    // user orbit + zoom around the target
    const off = pPos.sub(pTgt);
    if (this.zoom !== 1) off.multiplyScalar(this.zoom);
    off.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    const axis = new THREE.Vector3(0, 1, 0).cross(off).normalize();
    if (axis.lengthSq() > 0.5) off.applyAxisAngle(axis, this.pitch);
    const wantPos = pTgt.clone().add(off);
    const kPos = 1 - Math.exp(-dt * 4.2), kTgt = 1 - Math.exp(-dt * 5.0);
    this.pos.lerp(wantPos, kPos);
    this.tgt.lerp(pTgt, kTgt);
    this.fov += (fov - this.fov) * (1 - Math.exp(-dt * 3.4));
    this.cam.position.copy(this.pos);
    this.cam.position.y += Math.sin(t * 0.37) * 0.012;         // breathing
    this.cam.fov = this.fov;
    this.cam.updateProjectionMatrix();
    // the card view squares up to the lectern's own tilt
    if (!this.camUp) this.camUp = new THREE.Vector3(0, 1, 0);
    const upTarget = wantUp || new THREE.Vector3(0, 1, 0);
    this.camUp.lerp(upTarget, 1 - Math.exp(-dt * 4)).normalize();
    this.cam.up.copy(this.camUp);
    this.cam.lookAt(this.tgt.x, this.tgt.y + Math.sin(t * 0.29) * 0.02, this.tgt.z);
  }
}

/* ============================================================== the game ==== */
class Game {
  constructor() {
    this.hud = new HUD();
    this.lounge = new Lounge(document.getElementById('game'));
    this.lounge.camAuto = false;
    this.rig = new CameraRig(this.lounge.camera);
    this.mode = 'title';
    this.diff = 'classic';
    this.round = 1;
    this.coins = parseInt(Store.get('ll_coins', '500'), 10) || 500;
    this.pot = 0;
    this.tweens = [];
    this.queue = [];
    this.paused = false;
    this.t = 0;
    this.t0 = null;
    this.pauseAcc = 0;
    this._last = undefined;
    this.dust = 0;
    this.called = [];
    this.calledSet = new Set();
    this.ballPool = [];
    this.trayBalls = [];
    this.opponents = [];
    this.player = null;
    this.claimed = false;
    this.roundOver = false;
    this.power = { autoDaub: false, slowSip: false, luckyStar: false };
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.drag = { active: false, x: 0, y: 0, moved: 0, t: 0 };
    this.audioReady = false;
    this.bindUI();
    this.hud.setCoins(this.coins);
    this.loading = true;
    this.loop = this.loop.bind(this);
    requestAnimationFrame(this.loop);
    setTimeout(() => { this.hud.hideLoading(); }, 400);
  }

  /* ------------------------------------------------------------- audio ---- */
  initAudio() {
    if (this.audioReady) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    const ctx = new AC();
    const master = ctx.createGain(); master.gain.value = 0.85;
    const limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -6; limiter.knee.value = 6; limiter.ratio.value = 6; limiter.attack.value = 0.004; limiter.release.value = 0.2;
    limiter.connect(master); master.connect(ctx.destination);
    const sfxBus = ctx.createGain(); sfxBus.gain.value = 0.85;
    sfxBus.connect(limiter);
    this.audio = {
      ctx, master, limiter, sfxBus,
      sfx: new Sfx(ctx, sfxBus),
      ambience: new Ambience(ctx, sfxBus),
      caller: new Caller()
    };
    this.audioReady = true;
    this.sfxOn = true; this.voiceOn = true;
    if (ctx.state === 'suspended') ctx.resume();
  }
  startAudio() {
    if (!this.audioReady) return;
    const a = this.audio;
    if (a.ambience) a.ambience.start();
    if (a.ctx.state === 'suspended') a.ctx.resume();
  }
  toggleSfx() {
    this.sfxOn = !this.sfxOn;
    if (this.audioReady) {
      const a = this.audio;
      a.sfxBus.gain.setTargetAtTime(this.sfxOn ? 0.85 : 0, a.ctx.currentTime, 0.2);
    }
    document.getElementById('btnSfx').classList.toggle('on', this.sfxOn);
  }
  toggleVoice() {
    this.voiceOn = !this.voiceOn;
    if (this.audioReady) {
      this.audio.caller.enabled = this.voiceOn;
      if (!this.voiceOn) this.audio.caller.stop();
    }
    document.getElementById('btnVoice').classList.toggle('on', this.voiceOn);
  }
  fx(name, ...args) { if (this.sfxOn && this.audioReady) this.audio.sfx[name](...args); }
  speak(text, opts) {
    if (!this.voiceOn || !this.audioReady) return;
    this.audio.caller.say(text, opts);
  }
  callVoice(letter, num) {
    if (!this.voiceOn || !this.audioReady) return;
    this.audio.caller.callNumber(letter, num);
  }

  /* ------------------------------------------------------------------ UI -- */
  bindUI() {
    const hud = this.hud;
    document.querySelectorAll('[data-cam]').forEach((b) => {
      b.addEventListener('click', () => { this.rig.setPreset(b.dataset.cam); this.markCamBtn(b.dataset.cam); });
    });
    document.getElementById('btnSfx').addEventListener('click', () => this.toggleSfx());
    document.getElementById('btnVoice').addEventListener('click', () => this.toggleVoice());
    document.getElementById('btnHelp').addEventListener('click', () => this.showHelp());
    document.getElementById('btnShop').addEventListener('click', () => this.showShop());
    document.getElementById('btnAuto').addEventListener('click', () => this.toggleAutoDaub());
    document.getElementById('bingobtn').addEventListener('click', () => this.claim());
    document.querySelectorAll('#diffOpts .opt').forEach((o) => {
      o.addEventListener('click', () => {
        this.diff = o.dataset.diff;
        document.querySelectorAll('#diffOpts .opt').forEach((x) => x.classList.toggle('sel', x === o));
      });
    });
    document.getElementById('btnStart').addEventListener('click', () => this.start());
    window.addEventListener('keydown', (e) => {
      if (e.key === '1') { this.rig.setPreset('table'); this.markCamBtn('table'); }
      else if (e.key === '2') { this.rig.setPreset('card'); this.markCamBtn('card'); }
      else if (e.key === '3') { this.rig.setPreset('cage'); this.markCamBtn('cage'); }
      else if (e.key === '4') { this.rig.setPreset('screen'); this.markCamBtn('screen'); }
      else if (e.key === 'v' || e.key === 'V') this.toggleVoice();
      else if (e.key === 'Enter' && !document.getElementById('bingobtn').disabled) this.claim();
      else if (e.key === 'f' || e.key === 'F') this.daubAllCalled();
      else if (e.key === 'a' || e.key === 'A') this.toggleAutoDaub();
    });
    // pointer: drag to look, click to daub
    const cv = this.lounge.canvas;
    cv.addEventListener('pointerdown', (e) => {
      if (this.mode !== 'play') return;
      this.drag.active = true; this.drag.x = e.clientX; this.drag.y = e.clientY;
      this.drag.moved = 0; this.drag.t = this.t;
    });
    cv.addEventListener('pointermove', (e) => {
      if (!this.drag.active) return;
      const dx = e.clientX - this.drag.x, dy = e.clientY - this.drag.y;
      this.drag.moved += Math.abs(dx) + Math.abs(dy);
      this.rig.yaw = Math.max(-0.62, Math.min(0.62, this.rig.yaw - dx * 0.0032));
      this.rig.pitch = Math.max(-0.30, Math.min(0.34, this.rig.pitch - dy * 0.0022));
      this.drag.x = e.clientX; this.drag.y = e.clientY;
    });
    const endDrag = (e) => {
      if (!this.drag.active) return;
      this.drag.active = false;
      if (this.drag.moved < 7) this.handleClick(e.clientX, e.clientY);
    };
    cv.addEventListener('pointerup', endDrag);
    cv.addEventListener('pointercancel', () => { this.drag.active = false; });
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.rig.zoom = Math.max(0.55, Math.min(1.7, this.rig.zoom * (1 + Math.sign(e.deltaY) * 0.06)));
    }, { passive: false });
  }
  markCamBtn(name) {
    document.querySelectorAll('[data-cam]').forEach((b) => b.classList.toggle('on', b.dataset.cam === name));
  }

  /* --------------------------------------------------------------- setup -- */
  start() {
    this.initAudio();
    this.hud.hideTitle();
    this.startAudio();
    this.mode = 'play';
    this.newRound(true);
  }

  newRound(first) {
    const plan = ROUND_PLAN[(this.round - 1) % ROUND_PLAN.length];
    this.pattern = PATTERNS[plan];
    this.pot = 400 + this.round * 150 + (plan === 'blackout' ? 900 : 0);
    this.claimed = false; this.roundOver = false;
    this.called = []; this.calledSet = new Set();
    this.trayBalls.forEach((b) => this.lounge.scene.remove(b));
    this.trayBalls = [];
    this.ballPool = shuffledPool();
    this.phase = 'intro';
    this.nextDrawAt = this.t + 3.0;
    this.power = { autoDaub: false, slowSip: false, luckyStar: false };
    this.stats = { daubs: 0, missed: 0 };

    // player card
    if (this.playerRig) this.lounge.cardStand.remove(this.playerRig.group);
    this.playerRig = new CardRig(this.lounge, makeCard(7));
    this.player = this.playerRig;
    this.updateCardAnchor();

    // opponents
    const names = ['Rosa', 'Marty', 'Duke', 'Lena'];
    const speeds = { chill: [3200, 4200], classic: [1900, 2900], hot: [900, 1700] }[this.diff];
    this.opponents = names.map((nm, i) => ({
      name: nm, card: makeCard(20 + i), daubed: new Set([k(2, 2)]),
      speed: speeds[0] + Math.random() * (speeds[1] - speeds[0]),
      claim: 2200 + Math.random() * 2600,
      status: '', bingoAt: 0
    }));

    this.hud.setRound(this.round);
    this.hud.setPattern(this.pattern.name);
    this.hud.setPot(this.pot);
    this.hud.clearCalls();
    this.hud.bingoReady(false, 'BINGO!');
    const ab = document.getElementById('btnAuto');
    if (ab) ab.classList.remove('on');
    this.syncBoard();
    this.hud.hint(this.power.autoDaub ? 'Auto-daub is ON — your chips fly themselves.' :
      'Click the numbers on your card when they\'re called. <b>F</b> = daub everything available.');

    // cinematic: sweep the flashboard, then settle at the table
    this.rig.setPreset('screen');
    this.markCamBtn('');
    this.queue.push({ at: this.t + 3.4, fn: () => { this.rig.setPreset('table'); this.markCamBtn('table'); } });

    if (first) {
      this.speak('Welcome to the Lucky Lounge. Round ' + this.round + '. Pattern: ' + this.pattern.name + '.', { rate: 0.98 });
    } else {
      this.speak('Round ' + this.round + '. The pattern is ' + this.pattern.name + '. Good luck.', { rate: 0.98 });
    }
    this.hud.setStatus('Round <b>' + this.round + '</b> · ' + this.pattern.name + ' — ' + this.pattern.desc);
    this.queue.push({ at: this.t + 3.6, fn: () => this.beginBall() });
    this.phase = 'intro';
  }

  /* the lectern is angled, so the 'card' camera is aimed from its real transform */
  updateCardAnchor() {
    const stand = this.lounge.cardStand;
    stand.updateWorldMatrix(true, false);
    const center = new THREE.Vector3(0, 0.50, 0.06).applyMatrix4(stand.matrixWorld);
    const normal = new THREE.Vector3(0, 0, 1)
      .applyQuaternion(stand.getWorldQuaternion(new THREE.Quaternion()))
      .normalize();
    this.rig.cardAnchor = {
      pos: center.clone().addScaledVector(normal, 2.10).add(new THREE.Vector3(0, 0.10, 0)),
      look: center.clone().add(new THREE.Vector3(0, 0.01, 0)),
      fov: 48,
      up: new THREE.Vector3(0, 1, 0)
        .applyQuaternion(stand.getWorldQuaternion(new THREE.Quaternion()))
        .normalize()
    };
  }

  /* --------------------------------------------------------------- round -- */
  difficultyTiming() {
    const base = { chill: 6.4, classic: 5.0, hot: 3.8 }[this.diff];
    const ramp = Math.max(0.78, 1 - (this.round - 1) * 0.03);
    return base * ramp * (this.power.slowSip ? 1.35 : 1);
  }

  beginBall() {
    if (this.roundOver || this.phase === 'over') return;
    if (!this.ballPool.length) { this.endRound(null, 'The cage ran dry!'); return; }
    this.phase = 'spin';
    this.hud.setStatus('The caller spins the cage…');
    this.timerStart = this.t; this.timerEnd = this.t + this.difficultyTiming();
    this.lounge.spinCage(11.5);
    this.fx('cageCrank', this.audio.ctx.currentTime + 0.02, 12, 0.052);
    this.fx('ballRoll', this.audio.ctx.currentTime + 0.5, 0.9);
    const num = this.ballPool.pop();
    this.queue.push({ at: this.t + 1.15, fn: () => this.serveBall(num) });
  }

  serveBall(num) {
    if (this.roundOver) return;
    const L = this.lounge;
    const letter = letterOf(num);
    this.phase = 'serve';
    const ball = L.makeBallMesh(L.ballAtlas, num, 0.095);
    const start = new THREE.Vector3();
    L.cage.getWorldPosition(start);
    start.y -= 0.62;
    ball.position.copy(start);
    L.scene.add(ball);
    const chuteEnd = L.chuteEnd.clone().add(new THREE.Vector3(0, 0.58, 0));
    const rollY = 1.90;
    const rollEnd = new THREE.Vector3(2.55, rollY, 0.35);
    const A = { p0: start.clone(), p1: chuteEnd.clone() };
    const self = this;
    this.tweens.push({
      start: this.t, dur: 1.42,
      fn: (p) => {
        if (p < 0.34) {
          const q = p / 0.34;
          const e = q * q;
          ball.position.lerpVectors(A.p0, A.p1, e);
          ball.position.y = A.p0.y + (A.p1.y - A.p0.y) * e + Math.sin(q * Math.PI) * 0.10;
          ball.rotation.x -= 0.5;
        } else {
          const q = (p - 0.34) / 0.66;
          const e = 1 - Math.pow(1 - q, 2.1);
          ball.position.x = A.p1.x + (rollEnd.x - A.p1.x) * e;
          ball.position.z = A.p1.z + (rollEnd.z - A.p1.z) * e;
          ball.position.y = rollY;
          ball.rotation.z -= (rollEnd.x - A.p1.x) * (1 / 1.42) * 0.016;
        }
      },
      done: () => { self.landBall(num, letter, ball); }
    });
  }

  landBall(num, letter, ball) {
    const L = this.lounge;
    this.phase = 'daub';
    this.fx('ballDrop');
    // small ball settles onto the tray, big ball pops onto the pedestal
    L.scene.remove(ball);
    this.trayBalls.push(ball);
    const slot = L.traySlots[Math.min(9, this.trayBalls.length - 1)];
    const restY = slot.y + 0.65;            // tray rack sits on the raised podium
    ball.position.set(slot.x, restY + 0.55, slot.z);
    ball.scale.setScalar(0.9);
    L.scene.add(ball);
    this.tweens.push({
      start: this.t, dur: 0.5, fn: (p) => {
        const e = 1 - Math.pow(1 - p, 3);
        ball.position.y = restY + 0.55 - e * 0.55;
        ball.scale.setScalar(0.9 + Math.sin(p * Math.PI) * 0.25);
      }
    });
    if (this.trayBalls.length > 10) {
      const old = this.trayBalls.shift();
      L.scene.remove(old);
    }

    // big "now calling" ball on the pedestal
    if (this.bigBall) L.scene.remove(this.bigBall);
    this.bigBall = L.makeBallMesh(L.ballAtlas, num, 0.135);
    const ped = L.ballPedestal.getWorldPosition(new THREE.Vector3());
    this.bigBall.position.set(ped.x, ped.y + (L.ballRestY || 0.44), ped.z);
    L.scene.add(this.bigBall);
    this.bigBall.scale.setScalar(0.15);
    const big = this.bigBall;
    this.tweens.push({
      start: this.t, dur: 0.55, fn: (p) => {
        const s = p < 0.6 ? (p / 0.6) * 1.18 : 1.18 - ((p - 0.6) / 0.4) * 0.18;
        big.scale.setScalar(Math.max(0.15, s));
        big.rotation.y += 0.06;
      }, done: () => { big.scale.setScalar(1); }
    });

    // bookkeeping
    this.called.push(num);
    this.calledSet.add(num);
    this.hud.pushCall(letter, num, true);
    this.callVoice(letter, num);
    this.hud.setStatus('<b>' + letter + '-' + num + '</b> called — daub it!');
    const newBalls = Array.from(this.calledSet).length;
    this.syncBoard();

    // player highlight
    const cell = this.playerRig.cellOf(num);
    this.cellHit = null;
    if (cell) {
      this.playerRig.setHighlight(cell.row, cell.col, true);
      this.cellHit = cell;
      this.fx('ui', 'ding');
      if (this.power.autoDaub) {
        const self = this;
        this.queue.push({
          at: this.t + 0.5, fn: () => {
            if (!this.playerRig.daubed.has(k(cell.row, cell.col))) this.daub(cell.row, cell.col, true);
          }
        });
      }
    }
    // opponents react
    this.opponents.forEach((op) => {
      for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
        if (op.card.grid[r][c] === num) {
          const dly = op.speed * (0.7 + Math.random() * 0.6) / 1000;
          this.queue.push({
            at: this.t + Math.min(dly, this.difficultyTiming() - 0.6),
            fn: () => {
              op.daubed.add(k(r, c));
              op.status = 'daubed';
              const pr = progOf(op.daubed, this.pattern.groups);
              if (pr.done && !op.bingoAt) {
                op.bingoAt = this.t;
                op.status = 'BINGO!';
                this.fx('ui', 'ding');
                if (!this.roundOver) {
                  this.queue.push({
                    at: this.t + op.claim, fn: () => {
                      if (!this.roundOver && this.claimed !== true) this.endRound(op.name);
                    }
                  });
                }
              }
              this.syncBoard();
            }
          });
        }
      }
    });

    // end the daub window
    const timing = this.difficultyTiming();
    this.timerStart = this.t;
    this.timerEnd = this.t + timing;
    const hitCell = cell;
    this.queue.push({
      at: this.t + timing, fn: () => {
        if (this.roundOver) return;
        // a call that was never daubed is lost
        if (hitCell && !this.playerRig.daubed.has(k(hitCell.row, hitCell.col))) {
          this.stats.missed++;
          this.hud.toast('Missed <b>' + letter + '-' + num + '</b>', 'bad');
        }
        this.playerRig.clearHighlights();
        this.beginBall();
      }
    });
    this.syncBoard();
  }

  pendingPlayerCells() {
    const out = [];
    this.playerRig.card.grid.forEach((row, r) => row.forEach((n, c) => {
      if (n && this.calledSet.has(n) && !this.playerRig.daubed.has(k(r, c))) out.push([r, c]);
    }));
    return out;
  }
  daubAllCalled() {
    if (this.mode !== 'play') return;
    this.pendingPlayerCells().forEach(([r, c], i) => {
      const self = this;
      this.queue.push({ at: this.t + i * 0.06, fn: () => self.daub(r, c, true) });
    });
  }

  playerProgress() {
    return progOf(this.playerRig.daubed, this.pattern.groups).best;
  }

  daub(row, col, fromAuto) {
    if (this.roundOver) return;
    const n = this.playerRig.numAt(row, col);
    if (!n) return;
    if (this.playerRig.daubed.has(k(row, col))) return;
    if (!this.calledSet.has(n)) {
      this.playerRig.shake();
      this.fx('ui', 'bad');
      this.hud.toast('Not called yet — <b>' + letterOf(n) + '-' + n + '</b>', 'bad');
      return;
    }
    this.playerRig.dropChip(row, col, true);
    this.fx('chip', this.audioReady ? this.audio.ctx.currentTime : 0, (col - 2) / 3);
    this.stats.daubs++;
    this.coins += 5;
    this.hud.setCoins(this.coins);
    const pr = progOf(this.playerRig.daubed, this.pattern.groups);
    if (pr.done && !this.claimed) {
      this.hud.bingoReady(true);
      this.hud.setStatus('<b>BINGO!</b> Hit the lamp to claim the pot!');
      this.hud.toast('BINGO — claim it!', 'good');
      this.speak('Bingo! Claim it!', { rate: 1.08, pitch: 1.2 });
      this.lounge.camRig.shake = 0.02;
    }
    this.syncBoard();
  }

  handleClick(cx, cy) {
    const rect = this.lounge.canvas.getBoundingClientRect();
    this.pointer.x = ((cx - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((cy - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.lounge.camera);
    const hits = this.raycaster.intersectObject(this.playerRig.cardMesh, false);
    if (hits.length) {
      const cell = this.playerRig.pickFromUV(hits[0].uv);
      if (cell) this.daub(cell.row, cell.col, false);
    }
  }

  claim() {
    if (this.mode !== 'play' || this.roundOver) return;
    const pr = progOf(this.playerRig.daubed, this.pattern.groups);
    if (pr.done) {
      this.claimed = true;
      this.endRound('you');
    } else {
      // false claim: the house takes a fee and the crowd murmurs
      this.coins = Math.max(0, this.coins - 75);
      this.hud.setCoins(this.coins);
      this.hud.bingoReady(false, 'BINGO!');
      this.fx('ui', 'bad');
      this.hud.toast('Not a bingo yet! −75 bucks', 'bad');
      this.playerRig.shake();
    }
  }

  toggleAutoDaub() {
    this.power.autoDaub = !this.power.autoDaub;
    const btn = document.getElementById('btnAuto');
    if (btn) btn.classList.toggle('on', this.power.autoDaub);
    this.hud.toast(this.power.autoDaub ? 'Auto-daub ON — chips fly themselves.' : 'Auto-daub off — back to daubing by hand.', 'good');
    if (this.power.autoDaub) this.daubAllCalled();
    this.hud.hint(this.power.autoDaub ? 'Auto-daub is ON — your chips fly themselves.' :
      'Click the numbers on your card when they\u2019re called. <b>F</b> = daub everything available.');
  }

  /* ------------------------------------------------------------- round end -- */
  endRound(winner, note) {
    if (this.roundOver) return;
    this.roundOver = true;
    this.phase = 'over';
    this.playerRig.clearHighlights();
    const hud = this.hud;
    hud.bingoReady(false, 'BINGO!');
    const won = winner === 'you';
    let extra = '';
    if (won) {
      this.coins += this.pot;
      Store.set('ll_coins', this.coins);
      hud.setCoins(this.coins);
      this.fx('applause', 1.15, 4.0);
      this.fx('fanfare', true);
      setTimeout(() => this.fx('coin'), 400);
      this.speak('Bingo! The pot is yours.', { rate: 1.1, pitch: 1.15 });
      hud.burst(220, { fromTop: true });
      this.lounge.camRig.shake = 0.035;
      this.rig.setPreset('celebrate');
      this.markCamBtn('');
      this.spinCageVictory();
      extra = '<p class="sub" style="color:#8ff0c0">The room erupts. Pot of <b>' + this.pot.toLocaleString() + '</b> bucks is yours.</p>';
    } else {
      this.coins += 25;
      Store.set('ll_coins', this.coins);
      hud.setCoins(this.coins);
      this.fx('applause', 0.45, 2.4);
      this.fx('fanfare', false);
      this.speak('Bingo for ' + winner + '.', { rate: 1.0 });
      extra = '<p class="sub">' + winner + ' got there first. The house pays you 25 bucks for the effort.</p>';
    }
    const nextPattern = PATTERNS[ROUND_PLAN[this.round % ROUND_PLAN.length]];
    const potNext = 400 + (this.round + 1) * 150 + (ROUND_PLAN[this.round % ROUND_PLAN.length] === 'blackout' ? 900 : 0);
    const summary = '<h1>' + (won ? 'BINGO!' : 'SO CLOSE') + '</h1>' + extra +
      '<div class="rules" style="text-align:left">' +
      '<b>Round ' + this.round + ' wrap-up</b><br>' +
      'Pattern: ' + this.pattern.name + ' · Balls called: <b>' + this.called.length + '</b><br>' +
      'Chips placed: <b>' + this.stats.daubs + '</b> · Missed calls: <b>' + this.stats.missed + '</b><br>' +
      'Bank: <b>' + this.coins.toLocaleString() + '</b> bucks' +
      '</div>' +
      '<p class="sub">Next: round ' + (this.round + 1) + ' — <b>' + nextPattern.name + '</b> · pot ' + potNext.toLocaleString() + '</p>' +
      '<div class="row"><button class="bigbtn" id="btnNext">NEXT ROUND</button>' +
      '<button class="ghostbtn" id="btnShop2">Power-ups</button>' +
      '<button class="ghostbtn" id="btnWide">Back to the room</button></div>';
    hud.modal(summary, {
      onShow: (el) => {
        const n = el.querySelector('#btnNext');
        if (n) n.addEventListener('click', () => { hud.hideModal(); this.round++; this.newRound(false); });
        const s = el.querySelector('#btnShop2');
        if (s) s.addEventListener('click', () => this.showShop(true));
        const w = el.querySelector('#btnWide');
        if (w) w.addEventListener('click', () => { hud.hideModal(); this.rig.setPreset('table'); this.markCamBtn('table'); });
      }
    });
  }
  spinCageVictory() {
    this.lounge.spinCage(9);
    this.fx('cageCrank', this.audioReady ? this.audio.ctx.currentTime : 0, 10, 0.07);
  }

  /* ------------------------------------------------------------ board sync -- */
  syncBoard() {
    const players = [{
      name: 'You', isYou: true,
      progress: this.playerProgress(),
      status: this.claimed ? 'BINGO!' : (progOf(this.playerRig.daubed, this.pattern.groups).done ? 'claim!' : this.stats.daubs + ' chips')
    }];
    this.opponents.forEach((o) => players.push({
      name: o.name, isYou: false,
      progress: progOf(o.daubed, this.pattern.groups).best,
      status: o.status || 'playing'
    }));
    this.hud.setPlayers(players);
    this.lounge.updateWallBoard({
      title: 'LUCKY LOUNGE',
      round: this.round,
      patternName: this.pattern.name,
      pattern: { cells: this.pattern.diagram || [] },
      pot: this.pot,
      calledSet: this.calledSet,
      lastNum: this.called.length ? this.called[this.called.length - 1] : null,
      players: players
    });
  }

  /* ---------------------------------------------------------------- shop --- */
  showShop(fromModal) {
    const cost = { autoDaub: 250, slowSip: 150, luckyStar: 200 };
    const html = '<h2>The Lucky Counter</h2>' +
      '<p class="sub">Spend your bucks on a little extra luck. Bank: <b>' + this.coins.toLocaleString() + '</b> · ' +
      'Round ' + this.round + ' pattern: <b>' + this.pattern.name + '</b></p>' +
      '<div class="shopgrid">' +
      '<div class="shopitem' + (this.power.autoDaub ? ' owned' : '') + '"><h4>AUTO-DAUB</h4>' +
      '<p>Your chips fly to the card by themselves for the rest of this round. Never miss a call again.</p>' +
      '<button class="btn ' + (this.power.autoDaub ? '' : 'gold') + '" id="buyAuto">' + (this.power.autoDaub ? 'ACTIVE' : '250 bucks') + '</button></div>' +
      '<div class="shopitem' + (this.power.slowSip ? ' owned' : '') + '"><h4>SLOW SIP</h4>' +
      '<p>The caller nurses his drink: every ball takes 35% longer, so you get time to think.</p>' +
      '<button class="btn ' + (this.power.slowSip ? '' : 'gold') + '" id="buySlow">' + (this.power.slowSip ? 'ACTIVE' : '150 bucks') + '</button></div>' +
      '<div class="shopitem' + (this.power.luckyStar ? ' owned' : '') + '"><h4>LUCKY STAR</h4>' +
      '<p>A random square on your card daubs itself right now, free of charge.</p>' +
      '<button class="btn ' + (this.power.luckyStar ? '' : 'gold') + '" id="buyStar">' + (this.power.luckyStar ? 'USED' : '200 bucks') + '</button></div>' +
      '</div>' +
      '<div class="row"><button class="ghostbtn" id="closeShop">Back to the cards</button></div>';
    this.hud.modal(html, {
      onShow: (el) => {
        const buy = (kind, btn) => {
          if (this.coins < cost[kind]) { this.hud.toast('Not enough bucks.', 'bad'); return; }
          this.coins -= cost[kind];
          this.hud.setCoins(this.coins);
          Store.set('ll_coins', this.coins);
          this.fx('coin');
          if (kind === 'autoDaub') { this.power.autoDaub = true; this.hud.toast('Auto-daub engaged.', 'good'); }
          if (kind === 'slowSip') { this.power.slowSip = true; this.hud.toast('The caller slows right down.', 'good'); }
          if (kind === 'luckyStar') {
            this.power.luckyStar = true;
            const pending = this.pendingPlayerCells();
            const pick = pending.length ? pending[Math.floor(Math.random() * pending.length)]
              : [[2, 1], [2, 3], [1, 2], [3, 2]][Math.floor(Math.random() * 4)];
            this.playerRig.setHighlight(pick[0], pick[1], true);
            this.daub(pick[0], pick[1], true);
            this.hud.toast('Lucky Star! A square daubed itself.', 'good');
          }
          el.querySelector('#closeShop').textContent = 'Back to the cards';
          const si = { autoDaub: '#buyAuto', slowSip: '#buySlow', luckyStar: '#buyStar' }[kind];
          const b = el.querySelector(si);
          if (b) { b.textContent = kind === 'luckyStar' ? 'USED' : 'ACTIVE'; b.classList.remove('gold'); b.parentElement.classList.add('owned'); }
        };
        const a = el.querySelector('#buyAuto'), s = el.querySelector('#buySlow'), st = el.querySelector('#buyStar');
        if (a) a.addEventListener('click', () => buy('autoDaub'));
        if (s) s.addEventListener('click', () => buy('slowSip'));
        if (st) st.addEventListener('click', () => buy('luckyStar'));
        const c = el.querySelector('#closeShop');
        if (c) c.addEventListener('click', () => this.hud.hideModal());
      }
    });
  }
  showHelp() {
    const html = '<h2>How the lounge works</h2>' +
      '<div class="rules">' +
      '<b>Play</b><br>• Every ball the caller draws lights up on the giant flashboard and in the "Just called" tray.<br>' +
      '• When a number on your card is called it glows gold — click it to lay a chip. Miss it and the call is gone.<br>' +
      '• Complete the round pattern and the BINGO! lamp lights. Claim it before one of Rosa, Marty, Duke or Lena beats you to it.<br>' +
      '• False claims cost 75 bucks. Chips earn 5 bucks.<br><br>' +
      '<b>Camera</b><br>• Drag to look around the room · scroll to lean in · <kbd>1</kbd> wide · <kbd>2</kbd> card · <kbd>3</kbd> cage · <kbd>4</kbd> flashboard.<br><br>' +
      '<b>Sound</b><br>• Chips, the cage crank, ball drops, applause and the payout chime are all generated live — no audio files. ' +
      'The room keeps a low murmur with the odd glass clink.<br>' +
      '• <b>Caller</b> reads each ball aloud through your device\u2019s speech voice (toggle it in the top bar).' +
      '</div><div class="row"><button class="ghostbtn" id="closeHelp">Close</button></div>';
    this.hud.modal(html, { onShow: (el) => { const c = el.querySelector('#closeHelp'); if (c) c.addEventListener('click', () => this.hud.hideModal()); } });
  }

  /* ---------------------------------------------------------------- loop --- */
  loop() {
    requestAnimationFrame(this.loop);
    const now = performance.now();
    if (this._last === undefined) { this._last = now; this.t0 = now; }
    const dtWall = (now - this._last) / 1000;
    const dt = Math.min(0.1, dtWall);          // smooth things (camera, dust, band)
    const dtLogic = Math.min(0.4, dtWall);     // game animation keeps up on slow machines
    this._last = now;
    this._fps = this._fps ? this._fps * 0.9 + (1 / Math.max(0.001, dt)) * 0.1 : 1 / Math.max(0.001, dt);
    const modalOpen = !document.getElementById('overlay-modal').classList.contains('hide');
    this.paused = modalOpen && this.mode === 'play';
    // the game clock runs in wall time minus whatever was spent in menus,
    // so the caller never falls behind on a slow machine
    if (this.paused) this.pauseAcc += dt;
    else this.t = (now - this.t0 - this.pauseAcc) / 1000;
    // run the event queue (pauses while a modal is open)
    if (!this.paused) {
      let budget = 6;
      while (budget-- > 0) {
        let idx = -1;
        for (let i = 0; i < this.queue.length; i++) if (this.queue[i].at <= this.t) { idx = i; break; }
        if (idx < 0) break;
        const ev = this.queue.splice(idx, 1)[0];
        try { ev.fn(); } catch (e) { console.warn(e); }
      }
    }
    // tweens
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      const p = Math.min(1, (this.t - tw.start) / tw.dur);
      try { tw.fn(p); } catch (e) {}
      if (p >= 1) { if (tw.done) { try { tw.done(); } catch (e) {} } this.tweens.splice(i, 1); }
    }
    this.lounge.update(dt, this.t);
    if (this.playerRig) this.playerRig.update(dtLogic, this.t, this.t);
    this.rig.update(dtLogic, this.t);
    this.hud.update(dtLogic);
    // timer bar + status flourishes
    if (!this.paused && (this.phase === 'daub')) {
      const f = (this.timerEnd - this.t) / Math.max(0.001, this.timerEnd - this.timerStart);
      this.hud.setTimer(f);
    } else if (this.phase === 'spin' || this.phase === 'serve') {
      const f = (this.timerEnd - this.t) / Math.max(0.001, this.timerEnd - this.timerStart);
      this.hud.setTimer(Math.max(0, f));
    } else this.hud.setTimer(0);
    // idle status text
    if (this.mode === 'play' && !this.roundOver && this.phase === 'daub') {
      const pending = this.pendingPlayerCells().length;
      if (pending) this.hud.setStatus('<b>' + pending + '</b> called square' + (pending > 1 ? 's' : '') + ' waiting to be daubed');
    }
    this.autoQuality(dt);
    this.renderer();
  }
  /* if the machine can't hold a decent frame rate, quietly step down the
     quality ladder instead of letting the game stutter                  */
  autoQuality(dt) {
    if (this.qualityChecked) return;
    this._qAcc = (this._qAcc || 0) + dt;
    this._qFrames = (this._qFrames || 0) + 1;
    if (this._qAcc > 2.5 && this._qFrames > 20) {
      const fps = this._qFrames / this._qAcc;
      this._qAcc = 0; this._qFrames = 0;
      const L = this.lounge;
      if (fps < 24 && L.quality > 0) {
        L.setQuality(L.quality - 1);
        this.hud.toast(L.quality === 0 ? 'Reduced graphics quality for a smoother game' : 'Graphics quality lowered a notch');
      } else if (fps >= 24) {
        this.qualityChecked = true;
      }
    }
  }
  clockDelta() {
    if (!this._last) this._last = performance.now();
    const now = performance.now();
    const d = (now - this._last) / 1000;
    this._last = now;
    return Math.max(0, Math.min(0.1, d));
  }
  renderer() { this.lounge.renderer.render(this.lounge.scene, this.lounge.camera); }
}

function shuffledPool() {
  const pool = [];
  for (let n = 1; n <= 75; n++) pool.push(n);
  for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
  return pool;
}

window.addEventListener('load', () => {
  try {
    window.game = new Game();
  } catch (e) {
    console.error(e);
    document.getElementById('loading').textContent = 'Failed to start: ' + e.message;
  }
});
