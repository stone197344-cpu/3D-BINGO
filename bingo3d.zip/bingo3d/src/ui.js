/* ============================================================================
   ui.js — the lounge HUD: pills, call plate, table standings, toasts,
   win confetti and the modal system. Kept deliberately thin so the 3D room
   stays the star of the show.
   ========================================================================== */

class HUD {
  constructor() {
    this.el = {
      round: document.getElementById('uiRound'),
      pattern: document.getElementById('uiPattern'),
      pot: document.getElementById('uiPot'),
      coins: document.getElementById('uiCoins'),
      lastCalls: document.getElementById('lastCalls'),
      playerList: document.getElementById('playerList'),
      status: document.getElementById('status'),
      timerbar: document.getElementById('timerbar'),
      bingo: document.getElementById('bingobtn'),
      hint: document.getElementById('dauberhint'),
      toasts: document.getElementById('toasts'),
      modal: document.getElementById('overlay-modal'),
      modalBody: document.getElementById('modalBody'),
      title: document.getElementById('overlay-title'),
      confetti: document.getElementById('confetti'),
      loading: document.getElementById('loading')
    };
    this.cctx = this.el.confetti.getContext('2d');
    this.parts = [];
    this._resize();
    window.addEventListener('resize', () => this._resize());
  }
  _resize() {
    const c = this.el.confetti;
    c.width = window.innerWidth; c.height = window.innerHeight;
  }
  setRound(n) { this.el.round.textContent = n; }
  setPattern(name) { this.el.pattern.textContent = name; }
  setPot(n) { this.el.pot.textContent = n.toLocaleString(); }
  setCoins(n) { this.el.coins.textContent = n.toLocaleString(); }
  setStatus(html) { this.el.status.innerHTML = html; }
  setTimer(frac) { this.el.timerbar.style.width = Math.max(0, Math.min(1, frac)) * 100 + '%'; }
  bingoReady(on, label) {
    this.el.bingo.disabled = !on;
    this.el.bingo.classList.toggle('ready', !!on);
    if (label) this.el.bingo.textContent = label;
  }
  hint(html) { this.el.hint.innerHTML = html; }

  pushCall(letter, num, isNew) {
    const wrap = this.el.lastCalls;
    const d = document.createElement('div');
    d.className = 'mini-ball' + (isNew ? ' cur' : '');
    d.innerHTML = '<span>' + letter + '</span>' + num;
    wrap.insertBefore(d, wrap.firstChild);
    while (wrap.children.length > 5) wrap.removeChild(wrap.lastChild);
  }
  clearCalls() { this.el.lastCalls.innerHTML = ''; }

  setPlayers(list) {
    const wrap = this.el.playerList;
    if (!this._rows || this._rows.length !== list.length) {
      wrap.innerHTML = '';
      this._rows = list.map((p) => {
        const row = document.createElement('div');
        row.className = 'progrow' + (p.isYou ? ' you' : '');
        row.innerHTML = '<div class="nm"></div><div class="bar"><i></i></div><div class="st"></div>';
        wrap.appendChild(row);
        return { row, nm: row.querySelector('.nm'), bar: row.querySelector('i'), st: row.querySelector('.st') };
      });
    }
    list.forEach((p, i) => {
      const r = this._rows[i];
      r.nm.textContent = p.name;
      r.bar.style.width = Math.round(p.progress * 100) + '%';
      r.st.textContent = p.status || '';
    });
  }

  toast(msg, kind) {
    const d = document.createElement('div');
    d.className = 'toast ' + (kind || '');
    d.innerHTML = msg;
    this.el.toasts.appendChild(d);
    setTimeout(() => d.remove(), 3900);
  }

  modal(html, opts) {
    this.el.modalBody.innerHTML = html;
    this.el.modal.classList.remove('hide');
    if (opts && opts.onShow) opts.onShow(this.el.modalBody);
  }
  hideModal() { this.el.modal.classList.add('hide'); }
  hideTitle() { this.el.title.classList.add('hide'); }
  hideLoading() { if (this.el.loading) this.el.loading.style.display = 'none'; }

  /* ------------------------------------------------------------- confetti -- */
  burst(count, opts) {
    const o = opts || {};
    const W = this.el.confetti.width, H = this.el.confetti.height;
    const cols = o.colors || ['#e9c877', '#ffd76a', '#b8232f', '#f4ecd8', '#8ff0c0', '#7fe3ff'];
    for (let i = 0; i < count; i++) {
      const fromTop = o.fromTop !== false;
      this.parts.push({
        x: o.x !== undefined ? o.x : (fromTop ? Math.random() * W : W / 2),
        y: o.y !== undefined ? o.y : (fromTop ? -20 - Math.random() * 120 : H * 0.42),
        vx: (Math.random() - 0.5) * (o.spread || 220),
        vy: fromTop ? 60 + Math.random() * 140 : -260 - Math.random() * 300,
        g: 480, w: 5 + Math.random() * 8, h: 8 + Math.random() * 10,
        rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 9,
        col: cols[Math.floor(Math.random() * cols.length)],
        life: 2.6 + Math.random() * 2.2, t: 0
      });
    }
  }
  update(dt) {
    const c = this.cctx, W = this.el.confetti.width, H = this.el.confetti.height;
    if (!this.parts.length) { c.clearRect(0, 0, W, H); return; }
    c.clearRect(0, 0, W, H);
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.t += dt;
      p.vy += p.g * dt;
      p.vx *= 1 - 0.6 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      const a = Math.max(0, Math.min(1, p.t / 0.25)) * Math.max(0, 1 - Math.max(0, p.t - (p.life - 0.8)) / 0.8);
      c.save();
      c.globalAlpha = a;
      c.translate(p.x, p.y);
      c.rotate(p.rot);
      c.fillStyle = p.col;
      const sq = Math.abs(Math.cos(p.rot * 1.7));
      c.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * (0.35 + 0.65 * sq));
      c.restore();
      if (p.y > H + 60 || p.t > p.life) this.parts.splice(i, 1);
    }
  }
  clearConfetti() { this.parts.length = 0; }
}
