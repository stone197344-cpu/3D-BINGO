/* ============================================================================
   textures.js — every surface is painted procedurally on a <canvas>
   (no external images, so the game is fully self-contained & offline)
   ========================================================================== */

const Tex = (function () {
  const R = (seed) => { let s = seed || Math.random() * 1e9; return () => (s = (s * 16807) % 2147483647) / 2147483647; };
  let seedCounter = 987654321;
  const rnd = R(seedCounter);

  function cnv(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const x = c.getContext('2d', { willReadFrequently: true });
    return { c, x, w, h };
  }
  function tex(c, repX, repY) {
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    if (repX) t.repeat.set(repX, repY || repX);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }
  function noiseOverlay(x, w, h, amount, alpha) {
    const img = x.getImageData(0, 0, w, h);
    const d = img.data;
    for (let i = 0; i < d.length; i += 4) {
      const n = (Math.random() - 0.5) * amount;
      d[i] = Math.max(0, Math.min(255, d[i] + n));
      d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
      d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n));
      d[i + 3] = Math.max(0, Math.min(255, d[i + 3] * (alpha === undefined ? 1 : alpha)));
    }
    x.putImageData(img, 0, 0);
  }

  /* --------------------------------------------------------------- wood ----- */
  function wood(opt) {
    const o = Object.assign({ size: 1024, base: '#6b4423', dark: '#3a2211', light: '#a9773f', planks: 0, grain: 1, seed: 12345 }, opt);
    const { c, x, w, h } = cnv(o.size, o.size);
    const r = R(o.seed);
    x.fillStyle = o.base; x.fillRect(0, 0, w, h);
    // long grain streaks along X
    const lines = 420 * o.grain;
    for (let i = 0; i < lines; i++) {
      const y0 = r() * h;
      const amp = 3 + r() * 22;
      const wid = 0.6 + r() * 3.4;
      x.strokeStyle = r() < 0.55 ? o.dark : o.light;
      x.globalAlpha = 0.05 + r() * 0.20;
      x.lineWidth = wid;
      x.beginPath();
      x.moveTo(-20, y0);
      for (let px = 0; px <= w + 20; px += 14) {
        const yy = y0 + Math.sin((px / w) * Math.PI * (2 + r() * 1.5) + y0 * 0.01) * amp + (r() - 0.5) * 3;
        x.lineTo(px, yy);
      }
      x.stroke();
    }
    // knots
    for (let k = 0; k < 5; k++) {
      const kx = r() * w, ky = r() * h, kr = 6 + r() * 20;
      for (let i = 8; i > 0; i--) {
        x.globalAlpha = 0.09;
        x.strokeStyle = i % 2 ? o.dark : o.light;
        x.lineWidth = 1 + r() * 2;
        x.beginPath(); x.ellipse(kx, ky, kr * (i / 8) * 1.7, kr * (i / 8), r(), 0, Math.PI * 2); x.stroke();
      }
    }
    x.globalAlpha = 1;
    if (o.planks) {
      const ph = h / o.planks;
      for (let p = 0; p <= o.planks; p++) {
        const y = p * ph;
        x.fillStyle = 'rgba(0,0,0,0.55)'; x.fillRect(0, y - 1.5, w, 3);
        x.fillStyle = 'rgba(255,230,190,0.06)'; x.fillRect(0, y + 1.5, w, 2);
        // board end joints
        const bx = r() * w;
        x.fillStyle = 'rgba(0,0,0,0.45)'; x.fillRect(bx, y, 2.5, ph);
      }
      for (let p = 0; p < o.planks; p++) {
        x.fillStyle = 'rgba(0,0,0,' + (r() * 0.10).toFixed(3) + ')';
        x.fillRect(0, p * ph, w, ph);
      }
    }
    noiseOverlay(x, w, h, 12);
    return c;
  }

  /* --------------------------------------------------------------- felt ----- */
  function felt(color, seed) {
    const { c, x, w, h } = cnv(512, 512);
    const r = R(seed || 4242);
    x.fillStyle = color; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 26000; i++) {
      const a = r() * Math.PI * 2, len = 2 + r() * 7;
      const px = r() * w, py = r() * h;
      x.strokeStyle = r() < 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.10)';
      x.lineWidth = 0.7 + r() * 0.9;
      x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * len, py + Math.sin(a) * len); x.stroke();
    }
    noiseOverlay(x, w, h, 9);
    return c;
  }

  /* -------------------------------------------------------------- velvet ---- */
  function velvet(color, seed) {
    const { c, x, w, h } = cnv(512, 512);
    const r = R(seed || 777);
    x.fillStyle = color; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 42000; i++) {
      const px = r() * w, py = r() * h;
      const v = 0.5 + 0.5 * Math.sin((px * 0.35 + py * 0.12));
      x.fillStyle = 'rgba(255,255,255,' + (0.02 + v * 0.045).toFixed(3) + ')';
      x.fillRect(px, py, 1.4, 1.4);
      if (r() < 0.3) { x.fillStyle = 'rgba(0,0,0,0.05)'; x.fillRect(px + 1, py, 1.2, 1.2); }
    }
    noiseOverlay(x, w, h, 8);
    return c;
  }

  /* ---------------------------------------------------- bingo card face ----- */
  // Realistic card stock: cream paper, printed B-I-N-G-O header, ruled grid,
  // "FREE" centre star, subtle printed texture + ink bleed.
  function cardFace(card, opts) {
    const o = Object.assign({ w: 1024, h: 1360, tint: '#fdfaf0' }, opts || {});
    const { c, x, w, h } = cnv(o.w, o.h);
    const r = R(1337 + card.id * 31);
    // paper
    const g = x.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#fffdf6'); g.addColorStop(0.5, o.tint); g.addColorStop(1, '#f2ecda');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      x.fillStyle = 'rgba(120,100,70,' + (r() * 0.045).toFixed(3) + ')';
      x.fillRect(r() * w, r() * h, 1 + r() * 2, 1);
    }
    // printed border
    x.strokeStyle = '#1d4ea0'; x.lineWidth = 10;
    x.strokeRect(22, 22, w - 44, h - 44);
    x.strokeStyle = '#b8232f'; x.lineWidth = 3;
    x.strokeRect(38, 38, w - 76, h - 76);

    const headerH = 168;
    // header band
    const hg = x.createLinearGradient(0, 44, 0, headerH);
    hg.addColorStop(0, '#b8232f'); hg.addColorStop(1, '#8c1620');
    x.fillStyle = hg; x.fillRect(44, 44, w - 88, headerH - 44);
    const letters = ['B', 'I', 'N', 'G', 'O'];
    const cols = ['#ffffff', '#ffe9a8', '#ffffff', '#ffe9a8', '#ffffff'];
    x.textAlign = 'center'; x.textBaseline = 'middle';
    const cellW = (w - 88) / 5;
    for (let i = 0; i < 5; i++) {
      x.font = '900 108px Georgia, "Times New Roman", serif';
      x.fillStyle = 'rgba(0,0,0,0.35)';
      x.fillText(letters[i], 44 + cellW * (i + 0.5) + 4, 122 + 5);
      x.fillStyle = cols[i];
      x.fillText(letters[i], 44 + cellW * (i + 0.5), 122);
    }
    // grid
    const gy0 = headerH + 24;
    const gw = w - 88, gh = h - gy0 - 60;
    const cw = gw / 5, ch = gh / 5;
    x.strokeStyle = 'rgba(29,78,160,0.85)'; x.lineWidth = 5;
    for (let i = 0; i <= 5; i++) {
      x.beginPath(); x.moveTo(44 + i * cw, gy0); x.lineTo(44 + i * cw, gy0 + gh); x.stroke();
      x.beginPath(); x.moveTo(44, gy0 + i * ch); x.lineTo(44 + gw, gy0 + i * ch); x.stroke();
    }
    // numbers
    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        const n = card.grid[row][col];
        const cx = 44 + cw * (col + 0.5), cy = gy0 + ch * (row + 0.5);
        if (row === 2 && col === 2) {
          x.save();
          x.translate(cx, cy);
          x.fillStyle = 'rgba(184,35,47,0.13)';
          x.beginPath(); x.arc(0, 0, ch * 0.40, 0, Math.PI * 2); x.fill();
          // star burst
          x.fillStyle = '#b8232f';
          x.beginPath();
          for (let i = 0; i < 20; i++) {
            const ang = (i / 20) * Math.PI * 2 - Math.PI / 2;
            const rad = i % 2 === 0 ? ch * 0.30 : ch * 0.13;
            const px = Math.cos(ang) * rad, py = Math.sin(ang) * rad;
            i ? x.lineTo(px, py) : x.moveTo(px, py);
          }
          x.closePath(); x.fill();
          x.font = '700 34px Georgia, serif';
          x.fillStyle = '#fff';
          x.fillText('FREE', 0, 6);
          x.restore();
        } else {
          const ink = ['#15224a', '#0f1c3d', '#243b6d'][Math.floor(r() * 3)];
          x.fillStyle = 'rgba(0,0,0,0.10)';
          x.font = '700 118px "Trebuchet MS", Verdana, sans-serif';
          x.fillText(n, cx + 3, cy + 6);
          x.fillStyle = ink;
          x.fillText(n, cx, cy);
          // ink bleed halo
          x.globalAlpha = 0.06; x.fillStyle = '#1d4ea0';
          x.font = '700 122px "Trebuchet MS", Verdana, sans-serif';
          x.fillText(n, cx, cy + 1);
          x.globalAlpha = 1;
        }
      }
    }
    // serial + footer
    x.font = '600 26px "Courier New", monospace';
    x.fillStyle = 'rgba(40,30,10,0.55)';
    x.textAlign = 'left';
    x.fillText('NO. ' + String(card.serial).padStart(6, '0') + '-L', 60, h - 26);
    x.textAlign = 'right';
    x.fillText('LUCKY LOUNGE BINGO CLUB', w - 60, h - 26);
    x.textAlign = 'center';
    noiseOverlay(x, w, h, 10);
    return c;
  }

  /* --------------------------------------------------------- bingo ball ----- */
  // Atlas of all 75 balls: real ball look = white body, coloured bands per
  // column, black circle w/ letter+number.
  function ballAtlas() {
    // 8 columns x 10 rows (75 balls) — the mesh UVs in build3d expect a 8x10 layout
    const COLS = 8, ROWS = 10, CELL = 256, SIZE = COLS * CELL;
    const atlas = cnv(SIZE, ROWS * CELL);
    const bandCol = { B: ['#1d6fd0', '#0d3f80'], I: ['#d8362f', '#8c1620'], N: ['#2e9e58', '#146134'], G: ['#e8b21c', '#9c7106'], O: ['#e0731f', '#96400a'] };
    atlas.x.fillStyle = '#ffffff'; atlas.x.fillRect(0, 0, SIZE, ROWS * CELL);
    let idx = 0;
    for (const L of ['B', 'I', 'N', 'G', 'O']) {
      for (let n = 1; n <= 15; n++) {
        const gx = idx % COLS, gy = Math.floor(idx / COLS);
        const ox = gx * CELL, oy = gy * CELL;
        const x = atlas.x;
        x.save();
        x.beginPath(); x.rect(ox, oy, CELL, CELL); x.clip();
        x.fillStyle = '#fdfdff'; x.fillRect(ox, oy, CELL, CELL);
        // coloured bands (top/bottom) like a real bingo ball
        const bg = x.createLinearGradient(ox, oy, ox, oy + CELL);
        bg.addColorStop(0, bandCol[L][0]); bg.addColorStop(1, bandCol[L][1]);
        x.fillStyle = bg;
        x.fillRect(ox, oy, CELL, CELL * 0.20);
        const bg2 = x.createLinearGradient(ox, oy + CELL * 0.80, ox, oy + CELL);
        bg2.addColorStop(0, bandCol[L][1]); bg2.addColorStop(1, bandCol[L][0]);
        x.fillStyle = bg2;
        x.fillRect(ox, oy + CELL * 0.80, CELL, CELL * 0.20);
        // white circle + number
        const cx = ox + CELL / 2, cy = oy + CELL / 2;
        x.fillStyle = '#ffffff';
        x.beginPath(); x.arc(cx, cy, CELL * 0.30, 0, Math.PI * 2); x.fill();
        x.strokeStyle = 'rgba(0,0,0,0.25)'; x.lineWidth = CELL * 0.012;
        x.beginPath(); x.arc(cx, cy, CELL * 0.30, 0, Math.PI * 2); x.stroke();
        x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillStyle = '#141414';
        x.font = '900 ' + Math.round(CELL * 0.14) + 'px "Trebuchet MS", Verdana, sans-serif';
        x.fillText(L, cx, cy - CELL * 0.085);
        x.font = '900 ' + Math.round(CELL * 0.24) + 'px "Trebuchet MS", Verdana, sans-serif';
        x.fillText(n, cx, cy + CELL * 0.075);
        // specular sheen + gloss streak
        const sh = x.createRadialGradient(cx - CELL * 0.12, cy - CELL * 0.16, CELL * 0.02, cx, cy, CELL * 0.5);
        sh.addColorStop(0, 'rgba(255,255,255,0.55)'); sh.addColorStop(0.45, 'rgba(255,255,255,0.0)'); sh.addColorStop(1, 'rgba(0,0,0,0.10)');
        x.fillStyle = sh; x.fillRect(ox, oy, CELL, CELL);
        x.restore();
        idx++;
      }
    }
    return { canvas: atlas.c, grid: COLS, rows: ROWS };
  }

  /* --------------------------------------------------------- dart/daub chip - */
  function chip(color) {
    const { c, x, w, h } = cnv(256, 256);
    const g = x.createRadialGradient(80, 70, 8, 128, 128, 128);
    g.addColorStop(0, '#ffffff'); g.addColorStop(0.18, color); g.addColorStop(1, shade(color, -0.45));
    x.fillStyle = g; x.beginPath(); x.arc(128, 128, 126, 0, Math.PI * 2); x.fill();
    x.strokeStyle = 'rgba(255,255,255,0.55)'; x.lineWidth = 6;
    x.beginPath(); x.arc(128, 128, 104, 0, Math.PI * 2); x.stroke();
    x.strokeStyle = 'rgba(0,0,0,0.25)'; x.lineWidth = 3;
    x.beginPath(); x.arc(128, 128, 96, 0, Math.PI * 2); x.stroke();
    x.font = '900 84px Georgia, serif';
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillStyle = 'rgba(0,0,0,0.28)'; x.fillText('★', 130, 132);
    x.fillStyle = 'rgba(255,255,255,0.85)'; x.fillText('★', 128, 129);
    return c;
  }
  function shade(hex, amt) {
    const h = hex.replace('#', '');
    let r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16);
    r = Math.max(0, Math.min(255, Math.round(r + 255 * amt)));
    g = Math.max(0, Math.min(255, Math.round(g + 255 * amt)));
    b = Math.max(0, Math.min(255, Math.round(b + 255 * amt)));
    return '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
  }

  /* ------------------------------------------------------------- rug -------- */
  function rug(main, accent, seed) {
    const { c, x, w, h } = cnv(1024, 1024);
    const r = R(seed || 90210);
    x.fillStyle = main; x.fillRect(0, 0, w, h);
    // art-deco concentric + fan pattern
    x.strokeStyle = accent; x.lineWidth = 8;
    x.strokeRect(30, 30, w - 60, h - 60);
    x.strokeRect(58, 58, w - 116, h - 116);
    x.globalAlpha = 0.85;
    for (let ring = 0; ring < 9; ring++) {
      x.beginPath();
      x.arc(w / 2, h / 2, 120 + ring * 52, 0, Math.PI * 2);
      x.strokeStyle = ring % 2 ? accent : 'rgba(255,255,255,0.10)';
      x.lineWidth = ring % 2 ? 6 : 3;
      x.stroke();
    }
    // radial sunburst
    for (let i = 0; i < 48; i++) {
      const a = (i / 48) * Math.PI * 2;
      x.strokeStyle = i % 2 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.10)';
      x.lineWidth = 14;
      x.beginPath();
      x.moveTo(w / 2 + Math.cos(a) * 150, h / 2 + Math.sin(a) * 150);
      x.lineTo(w / 2 + Math.cos(a) * 700, h / 2 + Math.sin(a) * 700);
      x.stroke();
    }
    x.globalAlpha = 1;
    // corner medallions
    [[80, 80], [w - 80, 80], [80, h - 80], [w - 80, h - 80]].forEach(([cx, cy]) => {
      x.fillStyle = accent; x.beginPath(); x.arc(cx, cy, 34, 0, Math.PI * 2); x.fill();
      x.fillStyle = 'rgba(255,255,255,0.5)'; x.beginPath(); x.arc(cx, cy, 15, 0, Math.PI * 2); x.fill();
    });
    noiseOverlay(x, w, h, 22);
    return c;
  }

  /* ------------------------------------------------- art-deco wall poster --- */
  function poster(title, sub, bg, accent) {
    const { c, x, w, h } = cnv(760, 1024);
    const g = x.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, bg); g.addColorStop(1, shade(bg, -0.35));
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.strokeStyle = accent; x.lineWidth = 12; x.strokeRect(26, 26, w - 52, h - 52);
    x.lineWidth = 4; x.strokeRect(46, 46, w - 92, h - 92);
    // deco rays
    x.save(); x.translate(w / 2, h * 0.44);
    for (let i = 0; i < 30; i++) {
      const a = (i / 30) * Math.PI * 2;
      x.strokeStyle = 'rgba(255,255,255,0.10)'; x.lineWidth = 18;
      x.beginPath(); x.moveTo(Math.cos(a) * 90, Math.sin(a) * 90); x.lineTo(Math.cos(a) * 420, Math.sin(a) * 420); x.stroke();
    }
    x.restore();
    x.textAlign = 'center';
    x.fillStyle = accent;
    x.font = '900 96px Georgia, serif';
    x.fillText(title, w / 2, h * 0.40);
    x.font = '600 40px "Trebuchet MS", sans-serif';
    x.fillStyle = 'rgba(255,255,255,0.85)';
    const words = String(sub).split(' ');
    words.forEach((wd, i) => x.fillText(wd, w / 2, h * 0.52 + i * 52));
    // deco ornament
    x.strokeStyle = accent; x.lineWidth = 5;
    x.beginPath(); x.moveTo(w / 2 - 120, h * 0.78); x.lineTo(w / 2 + 120, h * 0.78); x.stroke();
    x.beginPath(); x.arc(w / 2, h * 0.78, 22, 0, Math.PI * 2); x.stroke();
    x.font = '500 30px "Trebuchet MS", sans-serif';
    x.fillStyle = 'rgba(255,255,255,0.6)';
    x.fillText('TONIGHT · 9 PM · NO COVER', w / 2, h * 0.90);
    noiseOverlay(x, w, h, 16);
    return c;
  }

  /* ------------------------------------------------ night-city window ------- */
  function cityscape(seed) {
    const { c, x, w, h } = cnv(2048, 1024);
    const r = R(seed || 5150);
    const sky = x.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#0a1430'); sky.addColorStop(0.55, '#1b2a54'); sky.addColorStop(1, '#3a3350');
    x.fillStyle = sky; x.fillRect(0, 0, w, h);
    // stars
    for (let i = 0; i < 700; i++) {
      x.fillStyle = 'rgba(255,255,255,' + (r() * 0.6).toFixed(2) + ')';
      x.fillRect(r() * w, r() * h * 0.45, 1 + r() * 2, 1 + r() * 2);
    }
    // three parallax layers of buildings
    for (let layer = 0; layer < 3; layer++) {
      const alpha = 0.35 + layer * 0.3;
      const baseY = h * (0.62 + layer * 0.12);
      let bx = -40;
      while (bx < w + 40) {
        const bw = 60 + r() * 150;
        const bh = (h * (0.18 + r() * 0.45)) * (0.6 + layer * 0.35);
        x.fillStyle = 'rgba(8,12,28,' + alpha.toFixed(2) + ')';
        x.fillRect(bx, baseY - bh, bw, h - baseY + bh);
        // windows
        const lit = 0.30 + r() * 0.35;
        for (let wy = baseY - bh + 12; wy < h - 16; wy += 20) {
          for (let wx = bx + 8; wx < bx + bw - 12; wx += 18) {
            if (r() < lit) {
              const warm = r();
              x.fillStyle = warm < 0.6 ? 'rgba(255,214,140,' + (0.35 + r() * 0.6).toFixed(2) + ')'
                : warm < 0.85 ? 'rgba(180,225,255,' + (0.3 + r() * 0.5).toFixed(2) + ')'
                  : 'rgba(255,160,190,' + (0.3 + r() * 0.4).toFixed(2) + ')';
              x.fillRect(wx, wy, 8, 11);
            }
          }
        }
        bx += bw + 6 + r() * 26;
      }
    }
    // street glow + haze
    const hz = x.createLinearGradient(0, h * 0.55, 0, h);
    hz.addColorStop(0, 'rgba(255,170,80,0.05)'); hz.addColorStop(1, 'rgba(255,150,60,0.30)');
    x.fillStyle = hz; x.fillRect(0, 0, w, h);
    return c;
  }

  /* ------------------------------------------------ wood floor (parquet) ---- */
  function floor() {
    const { c, x, w, h } = cnv(1024, 1024);
    const r = R(24680);
    x.fillStyle = '#3a2517'; x.fillRect(0, 0, w, h);
    const plankH = h / 8;
    for (let row = 0; row < 8; row++) {
      let px = -(row % 2) * 120;
      while (px < w) {
        const pw = 220 + r() * 200;
        const shadeV = 0.75 + r() * 0.5;
        const base = [64, 42, 26];
        x.fillStyle = 'rgb(' + Math.round(base[0] * shadeV) + ',' + Math.round(base[1] * shadeV) + ',' + Math.round(base[2] * shadeV) + ')';
        x.fillRect(px, row * plankH, pw - 3, plankH - 3);
        // grain
        for (let i = 0; i < 40; i++) {
          const gy = row * plankH + r() * plankH;
          x.strokeStyle = r() < 0.5 ? 'rgba(0,0,0,0.20)' : 'rgba(190,140,90,0.14)';
          x.lineWidth = 0.6 + r() * 1.8;
          x.beginPath();
          x.moveTo(px, gy);
          for (let sx = px; sx < px + pw; sx += 20) x.lineTo(sx, gy + Math.sin(sx * 0.03 + i) * 4 + (r() - 0.5) * 2);
          x.stroke();
        }
        // bevel
        x.fillStyle = 'rgba(0,0,0,0.5)'; x.fillRect(px + pw - 3, row * plankH, 3, plankH);
        px += pw;
      }
      x.fillStyle = 'rgba(0,0,0,0.5)'; x.fillRect(0, row * plankH + plankH - 3, w, 3);
    }
    noiseOverlay(x, w, h, 14);
    return c;
  }

  /* --------------------------------------------------- perforated metal ----- */
  function mesh(seed) {
    const { c, x, w, h } = cnv(512, 512);
    x.fillStyle = '#20242c'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 260; i++) {
      x.fillStyle = 'rgba(255,255,255,0.02)';
      x.fillRect(Math.random() * w, Math.random() * h, 40, 2);
    }
    return c;
  }

  /* -------------------------------------------------- brass / gold detail --- */
  function brass(seed) {
    const { c, x, w, h } = cnv(512, 512);
    const r = R(seed || 31415);
    const g = x.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#8d6a24'); g.addColorStop(0.4, '#d9b45a'); g.addColorStop(0.6, '#f0dc9a'); g.addColorStop(1, '#8a6520');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 2500; i++) {
      x.strokeStyle = 'rgba(255,255,255,' + (r() * 0.10).toFixed(3) + ')';
      x.lineWidth = 1;
      const y = r() * h;
      x.beginPath(); x.moveTo(0, y); x.lineTo(w, y + (r() - 0.5) * 6); x.stroke();
    }
    noiseOverlay(x, w, h, 18);
    return c;
  }

  return { cnv, tex, wood, felt, velvet, cardFace, ballAtlas, chip, rug, poster, cityscape, floor, mesh, brass, shade, noiseOverlay, rnd };
})();

/* ============================================================================
   The big LED wall board — a "real" dot-matrix style display panel.
   Drawn with an LED grid overlay so it reads as physical hardware, not HTML.
   ========================================================================== */
class WallBoard {
  /* The giant flashboard: a wide, self-lit LED wall panel. Layout matches the
     9.4 x 3.7 m plane it is mapped onto (aspect ~2.54). */
  constructor(width, height, theme) {
    const { c, x, w, h } = Tex.cnv(width, height);
    this.canvas = c; this.x = x; this.w = w; this.h = h;
    this.theme = theme || { led: '#ffb347', accent: '#ff4d4d' };
    this.state = null;
    this.dirty = true;
    const dot = Tex.cnv(3, 3);
    dot.x.fillStyle = '#000';
    dot.x.fillRect(2, 0, 1, 3);
    dot.x.fillRect(0, 2, 3, 1);
    this.dotPattern = x.createPattern(dot.c, 'repeat');
    this.colColor = ['#5aa9ff', '#ff6a60', '#52e08f', '#ffd75c', '#ffa64d'];
  }

  draw(S) {
    S = S || {};
    const { x, w, h, theme } = this;
    const bg = x.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#1a2130'); bg.addColorStop(0.45, '#0b0f18'); bg.addColorStop(1, '#05070c');
    x.fillStyle = bg; x.fillRect(0, 0, w, h);
    const vg = x.createRadialGradient(w / 2, h / 2, 60, w / 2, h / 2, w * 0.55);
    vg.addColorStop(0, 'rgba(180,220,255,0.07)'); vg.addColorStop(1, 'rgba(0,0,0,0.42)');
    x.fillStyle = vg; x.fillRect(0, 0, w, h);

    const pad = 22;
    /* ---- header ---- */
    x.fillStyle = 'rgba(255,255,255,0.055)';
    x.fillRect(pad, pad, 760, 112);
    x.textBaseline = 'middle'; x.textAlign = 'left';
    x.fillStyle = theme.led;
    x.font = '900 62px "Trebuchet MS", Verdana, sans-serif';
    x.fillText('LUCKY LOUNGE', pad + 22, pad + 44);
    x.font = '700 30px "Trebuchet MS", sans-serif';
    x.fillStyle = '#9fb4d0';
    x.fillText('BINGO CLUB \u00b7 ROUND ' + (S.round || 1), pad + 24, pad + 88);
    x.font = '600 24px "Trebuchet MS", sans-serif';
    x.fillStyle = '#6f8399';
    x.fillText('PATTERN', pad + 448, pad + 34);
    x.font = '900 38px "Trebuchet MS", sans-serif';
    x.fillStyle = '#7fe3ff';
    x.fillText(String(S.patternName || 'ANY LINE').toUpperCase(), pad + 448, pad + 74);
    x.fillStyle = 'rgba(255,255,255,0.06)';
    x.fillRect(pad + 800, pad, 440, 112);
    x.fillStyle = theme.accent;
    x.font = '700 26px "Trebuchet MS", sans-serif';
    x.fillText('THE POT', pad + 822, pad + 34);
    x.font = '900 54px "Trebuchet MS", sans-serif';
    x.fillStyle = '#ffd76a';
    x.fillText((S.pot || 0).toLocaleString() + '  BUCKS', pad + 822, pad + 78);
    const dgx = pad + 1270, dgy = pad + 18, dgc = 15;
    x.fillStyle = 'rgba(0,0,0,0.35)';
    x.fillRect(dgx - 12, dgy - 12, 5 * dgc + 16, 5 * dgc + 16);
    for (let r0 = 0; r0 < 5; r0++) for (let c0 = 0; c0 < 5; c0++) {
      const on = ((S.pattern && S.pattern.cells) || []).some((cc) => cc[0] === r0 && cc[1] === c0);
      x.fillStyle = on ? theme.accent : 'rgba(255,255,255,0.13)';
      x.fillRect(dgx + c0 * dgc, dgy + r0 * dgc, dgc - 2, dgc - 2);
    }

    /* ---- number wall: 5 letters x 3 rows x 5 numbers = 75 tiles ---- */
    const top = 152, bottom = h - 150;
    const wallW = w - pad * 2;
    const groupW = wallW / 5;
    const tileW = (groupW - 10) / 5;
    const letterH = 62;
    const rowH = (bottom - top - letterH) / 3;
    const letters = ['B', 'I', 'N', 'G', 'O'];
    for (let gi = 0; gi < 5; gi++) {
      const gx = pad + gi * groupW;
      x.fillStyle = this.colColor[gi];
      x.fillRect(gx, top, groupW - 10, letterH - 6);
      x.fillStyle = '#0a0d14';
      x.font = '900 46px "Trebuchet MS", sans-serif';
      x.textAlign = 'center';
      x.fillText(letters[gi], gx + (groupW - 10) / 2, top + (letterH - 6) / 2);
      for (let r0 = 0; r0 < 3; r0++) {
        for (let c0 = 0; c0 < 5; c0++) {
          const num = gi * 15 + r0 * 5 + c0 + 1;
          const tx = gx + c0 * tileW;
          const ty = top + letterH + r0 * rowH;
          const called = S.calledSet && S.calledSet.has(num);
          const isLast = S.lastNum === num;
          if (called) {
            x.fillStyle = isLast ? this.colColor[gi] : 'rgba(255,255,255,0.16)';
            x.fillRect(tx, ty, tileW - 6, rowH - 8);
            x.fillStyle = isLast ? '#0a0d14' : this.colColor[gi];
            x.font = '900 ' + Math.round(rowH * 0.52) + 'px "Trebuchet MS", sans-serif';
            x.textAlign = 'center';
            x.fillText(num, tx + (tileW - 6) / 2, ty + (rowH - 8) / 2);
            if (isLast) {
              x.strokeStyle = '#ffffff'; x.lineWidth = 4;
              x.strokeRect(tx + 3, ty + 3, tileW - 12, rowH - 14);
            }
          } else {
            x.fillStyle = 'rgba(255,255,255,0.045)';
            x.fillRect(tx, ty, tileW - 6, rowH - 8);
            x.fillStyle = 'rgba(255,255,255,0.10)';
            x.font = '700 ' + Math.round(rowH * 0.42) + 'px "Trebuchet MS", sans-serif';
            x.textAlign = 'center';
            x.fillText(num, tx + (tileW - 6) / 2, ty + (rowH - 8) / 2);
          }
        }
      }
    }

    /* ---- player standings ---- */
    const py = h - 132;
    x.fillStyle = 'rgba(255,255,255,0.05)'; x.fillRect(pad, py, w - pad * 2, 106);
    const players = S.players || [];
    const pw = (w - pad * 2) / Math.max(1, players.length);
    players.forEach((p, i) => {
      const px = pad + i * pw;
      x.textAlign = 'left';
      x.fillStyle = p.isYou ? theme.led : '#cfdcec';
      x.font = '700 30px "Trebuchet MS", sans-serif';
      x.fillText((p.isYou ? '> ' : '') + p.name, px + 18, py + 30);
      x.fillStyle = 'rgba(255,255,255,0.12)';
      x.fillRect(px + 18, py + 50, pw - 44, 16);
      const grad = x.createLinearGradient(px + 18, 0, px + pw - 26, 0);
      grad.addColorStop(0, p.isYou ? '#43d17a' : '#4d9fff');
      grad.addColorStop(1, p.isYou ? '#9dffc4' : '#9fd2ff');
      x.fillStyle = grad;
      x.fillRect(px + 18, py + 50, (pw - 44) * Math.max(0, Math.min(1, p.progress || 0)), 16);
      x.fillStyle = '#8b9bb0';
      x.font = '600 22px "Trebuchet MS", sans-serif';
      x.fillText(p.status || '', px + 18, py + 90);
    });

    /* ---- LED dot-matrix overlay + sheen ---- */
    x.globalCompositeOperation = 'multiply';
    x.globalAlpha = 0.42;
    x.fillStyle = this.dotPattern;
    x.fillRect(0, 0, w, h);
    x.globalAlpha = 1;
    x.globalCompositeOperation = 'source-over';
    const sheen = x.createLinearGradient(0, 0, w * 0.7, h);
    sheen.addColorStop(0, 'rgba(255,255,255,0.10)');
    sheen.addColorStop(0.4, 'rgba(255,255,255,0.0)');
    sheen.addColorStop(1, 'rgba(255,255,255,0.03)');
    x.fillStyle = sheen; x.fillRect(0, 0, w, h);
    this.dirty = true;
  }
}
