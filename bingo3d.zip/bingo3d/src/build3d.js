/* ============================================================================
   build3d.js — the Lucky Lounge: a fully modelled 3D jazz club
   Room, bar, bandstand with animated trio, audience, chandeliers, dust motes,
   the brass bingo cage on its masterboard, the giant LED flashboard, and the
   player's own card console.
   ========================================================================== */

const COL = {
  woodDark: 0x4a2f1c, woodMid: 0x74492a, woodLight: 0xa9764a,
  brass: 0xd9b45a, brassDark: 0x8d6a24, chrome: 0xcfd6dd,
  feltRed: 0x35623f, feltTable: 0x8e1f2c, feltBoard: 0x123324,
  wall: 0x2b1d24, wallTrim: 0x3d2a33, ceiling: 0x1a1418,
  curtain: 0x5a1220, seat: 0x6d1622, lamp: 0xffcf87
};

function mat(opts) { return new THREE.MeshStandardMaterial(opts); }

/* ---------------------------------------------------------------- merging --
   Props are built from dozens of little primitives, which is lovely to write
   and terrible for draw calls. mergeParts() bakes every static child of a group
   into one mesh per material, keeping animated children (arms, heads, rotors)
   alive and separate. */
function mergeGeos(geos) {
  const names = ['position', 'normal', 'uv'];
  const total = geos.reduce((s, g) => s + g.attributes.position.count, 0);
  const out = new THREE.BufferGeometry();
  names.forEach((name) => {
    const first = geos.find((g) => g.attributes[name]);
    const size = first ? first.attributes[name].itemSize : 3;
    const arr = new Float32Array(total * size);
    let off = 0;
    geos.forEach((g) => {
      const a = g.attributes[name];
      if (a) { arr.set(a.array.subarray ? a.array.subarray(0, a.count * size) : a.array, off); }
      off += g.attributes.position.count * size;
    });
    out.setAttribute(name, new THREE.BufferAttribute(arr, size));
  });
  return out;
}
function mergeParts(group, keep) {
  group.updateWorldMatrix(true, true);
  const inv = new THREE.Matrix4().copy(group.matrixWorld).invert();
  const buckets = new Map();
  const remove = [];
  group.children.slice().forEach((child) => {
    if (!child.isMesh || child.userData.keep) return;
    if (keep && keep.indexOf(child) >= 0) return;
    if (!child.geometry || !child.geometry.attributes.position) return;
    let geo = child.geometry.index ? child.geometry.toNonIndexed() : child.geometry.clone();
    if (!geo.attributes.uv) {
      const n = geo.attributes.position.count;
      geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
    }
    if (!geo.attributes.normal) geo.computeVertexNormals();
    const m = new THREE.Matrix4().copy(inv).multiply(child.matrixWorld);
    geo.applyMatrix4(m);
    const key = child.material.uuid || child.material;
    if (!buckets.has(key)) buckets.set(key, { mat: child.material, geos: [] });
    buckets.get(key).geos.push(geo);
    remove.push(child);
  });
  remove.forEach((c) => group.remove(c));
  const out = [];
  buckets.forEach(({ mat: m, geos }) => {
    const mesh = new THREE.Mesh(mergeGeos(geos), m);
    mesh.castShadow = true; mesh.receiveShadow = true;
    group.add(mesh);
    out.push(mesh);
  });
  return out;
}
function woodMat(cvs, rough, metal, rep) {
  const t = Tex.tex(cvs, rep || 1);
  return mat({ map: t, roughness: rough === undefined ? 0.6 : rough, metalness: metal || 0.05 });
}

class Lounge {
  constructor(canvas) {
    this.canvas = canvas;
    this.clock = new THREE.Clock();
    this.movers = [];          // animated objects
    this.pickables = [];
    this.sprites = [];
    this.dust = null;
    this._ballPool = {};
    this.init();
  }

  /* ------------------------------------------------------------- renderer -- */
  init() {
    const q = (new URLSearchParams(location.search).get('q') || 'high').toLowerCase();
    this.quality = q === 'low' ? 0 : q === 'med' ? 1 : 2;
    const renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: q !== 'low', powerPreference: 'high-performance' });
    renderer.setPixelRatio(q === 'low' ? 0.6 : Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.22;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer = renderer;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x07070c);
    scene.fog = new THREE.FogExp2(0x0d0a10, 0.018);
    this.scene = scene;

    const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.05, 200);
    camera.position.set(0, 2.30, 7.60);
    this.camera = camera;
    this.camTarget = new THREE.Vector3(0.10, 1.95, -1.0);
    this.camRig = { yaw: 0, pitch: 0, dist: 0, shake: 0 };
    this.camAuto = true;

    // environment for metal / lacquer reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();
    const mk = (color, intensity, pos, scale) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1),
        new THREE.MeshStandardMaterial({ color: 0x000000, emissive: color, emissiveIntensity: intensity }));
      m.position.set(pos[0], pos[1], pos[2]); m.scale.set(scale[0], scale[1], scale[2]);
      envScene.add(m);
    };
    mk(0xffd9a0, 3.2, [0, 6, 0], [4, 0.4, 4]);          // warm chandeliers above
    mk(0xffb066, 1.6, [-8, 2, -6], [0.4, 3, 8]);         // stage wash
    mk(0x5577ff, 0.7, [9, 3, -8], [3, 0.4, 2]);          // cool window
    mk(0x221616, 0.6, [0, -2, 0], [20, 0.3, 20]);        // floor bounce
    mk(0x66ccff, 1.1, [0, 3.2, -9], [7, 3, 0.3]);        // big screen glow
    this.env = pmrem.fromScene(envScene, 0.04).texture;
    scene.environment = this.env;
    scene.environmentIntensity = 0.55;

    this.buildRoom();
    this.buildBar();
    this.buildBandstand();
    this.buildAudience();
    this.buildTables();
    this.buildBingoRig();
    this.buildWallBoard();
    this.buildLights();
    this.buildDust();
    this.setQuality(this.quality);
    this.onResize();
    window.addEventListener('resize', () => this.onResize());
  }

  /* quality ladder: 0 = low (integrated / software GL), 1 = medium, 2 = high */
  setQuality(level) {
    this.quality = level;
    const r = this.renderer;
    r.shadowMap.enabled = level >= 1;
    r.setPixelRatio(level === 0 ? 0.6 : level === 1 ? Math.min(window.devicePixelRatio || 1, 1) : Math.min(window.devicePixelRatio || 1, 1.75));
    r.shadowMap.needsUpdate = true;
    if (this.keyLight) {
      this.keyLight.castShadow = level >= 1;
      if (level >= 1 && this.keyLight.shadow.mapSize.width !== (level === 1 ? 768 : 1024)) {
        this.keyLight.shadow.mapSize.set(level === 1 ? 768 : 1024, level === 1 ? 768 : 1024);
        if (this.keyLight.shadow.map) { this.keyLight.shadow.map.dispose(); this.keyLight.shadow.map = null; }
      }
    }
    if (this.dust) this.dust.visible = level >= 1;
    this.scene.fog.density = level === 0 ? 0.02 : 0.026;
    this.onResize();
  }

  onResize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    // widen fov on tall/narrow screens so the whole tableau still fits
    this.camera.fov = w / h < 1.35 ? 58 : 46;
    this.camera.updateProjectionMatrix();
  }

  /* ----------------------------------------------------------------- room -- */
  buildRoom() {
    const S = this.scene;
    const W = 26, D = 22, H = 5.6;

    // floor: parquet + rug
    const floorT = Tex.tex(Tex.floor(), 5, 4);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat({ map: floorT, roughness: 0.38, metalness: 0.02, envMapIntensity: 0.7 }));
    floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0, -1.5);
    floor.receiveShadow = true; S.add(floor);
    this.floor = floor;

    const rugT = Tex.tex(Tex.rug('#2c2a52', '#c9a95c', 4321), 1);
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(13, 11), mat({ map: rugT, roughness: 0.94 }));
    rug.rotation.x = -Math.PI / 2; rug.position.set(0.2, 0.012, 0.2);
    rug.receiveShadow = true; S.add(rug);

    // walls
    const wallT = Tex.tex(Tex.velvet('#40202b', 33), 6, 2);
    const wallMat = mat({ map: wallT, roughness: 0.95, color: 0xffffff, envMapIntensity: 0.35 });
    const walls = [
      { pos: [0, H / 2, -D / 2 - 1.5], rot: 0, w: W },
      { pos: [-W / 2, H / 2, -1.5], rot: Math.PI / 2, w: D },
      { pos: [W / 2, H / 2, -1.5], rot: -Math.PI / 2, w: D },
      { pos: [0, H / 2, D / 2 - 1.5], rot: Math.PI, w: W }
    ];
    walls.forEach((wdef) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(wdef.w, H), wallMat);
      m.position.set(wdef.pos[0], wdef.pos[1], wdef.pos[2]);
      m.rotation.y = wdef.rot;
      m.receiveShadow = true;
      S.add(m);
    });

    // wainscot / dado rail + art deco pilasters
    const trimMat = mat({ color: COL.woodMid, roughness: 0.42, metalness: 0.08, envMapIntensity: 0.9 });
    const dado = new THREE.Mesh(new THREE.BoxGeometry(W, 0.95, 0.14), trimMat);
    dado.position.set(0, 0.48, -D / 2 - 1.42); S.add(dado);
    const railMat = mat({ color: COL.brass, roughness: 0.24, metalness: 0.95, envMapIntensity: 1.4 });
    const rail = new THREE.Mesh(new THREE.BoxGeometry(W, 0.05, 0.09), railMat);
    rail.position.set(0, 0.98, -D / 2 - 1.38); S.add(rail);
    for (let i = -3; i <= 3; i++) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.4, 0.22), trimMat);
      p.position.set(i * 3.6, 1.2, -D / 2 - 1.36); S.add(p);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.16, 0.34), railMat);
      cap.position.set(i * 3.6, 2.46, -D / 2 - 1.34); S.add(cap);
    }
    const dadoL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.95, D), trimMat);
    dadoL.position.set(-W / 2 + 0.08, 0.48, -1.5); S.add(dadoL);
    const dadoR = dadoL.clone(); dadoR.position.x = W / 2 - 0.08; S.add(dadoR);

    // ceiling: dark coffers + beams
    const ceilMat = mat({ color: COL.ceiling, roughness: 0.9 });
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D), ceilMat);
    ceil.rotation.x = Math.PI / 2; ceil.position.set(0, H, -1.5); S.add(ceil);
    const beamMat = mat({ color: 0x2a1c14, roughness: 0.7 });
    for (let i = -3; i <= 3; i++) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, D), beamMat);
      b.position.set(i * 3.4, H - 0.22, -1.5); S.add(b);
    }
    const beamF = new THREE.Mesh(new THREE.BoxGeometry(W, 0.42, 0.5), beamMat);
    beamF.position.set(0, H - 0.22, -2); S.add(beamF);

    // windows on the right wall: night city + curtains + mullions
    const cityTex = Tex.tex(Tex.cityscape(9001), 1);
    const winMat = mat({ map: cityTex, emissive: 0xffffff, emissiveMap: cityTex, emissiveIntensity: 0.85, roughness: 1, toneMapped: true });
    const frameMat = mat({ color: 0x241a12, roughness: 0.6 });
    for (let i = 0; i < 3; i++) {
      const z = -7 + i * 5.2;
      const win = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 2.6), winMat);
      win.position.set(W / 2 - 0.09, 2.7, z);
      win.rotation.y = -Math.PI / 2;
      S.add(win);
      const fr = new THREE.Mesh(new THREE.BoxGeometry(0.18, 3.0, 3.8), frameMat);
      fr.position.set(W / 2 - 0.12, 2.7, z); S.add(fr);
      const inner = new THREE.Mesh(new THREE.PlaneGeometry(3.3, 2.5), winMat);
      inner.position.set(W / 2 - 0.22, 2.7, z); inner.rotation.y = -Math.PI / 2; S.add(inner);
      // mullions
      const mv = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.6, 0.07), frameMat);
      mv.position.set(W / 2 - 0.26, 2.7, z); S.add(mv);
      const mh = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.07, 3.4), frameMat);
      mh.position.set(W / 2 - 0.26, 2.7, z); S.add(mh);
      // curtain swags
      const curt = mat({ map: Tex.tex(Tex.velvet('#66121f', 12 + i), 3, 1), color: 0xffffff, roughness: 0.92 });
      for (const side of [-1, 1]) {
        const cm = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.34, 3.2, 12, 1, true, 0, Math.PI), curt);
        cm.position.set(W / 2 - 0.5, 2.7, z + side * 2.05);
        cm.rotation.z = Math.PI / 2;
        cm.rotation.y = -Math.PI / 2;
        cm.material.side = THREE.DoubleSide;
        S.add(cm);
      }
      const pel = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 4.6), curt);
      pel.position.set(W / 2 - 0.42, 4.35, z); S.add(pel);
    }

    // art-deco posters on the back wall flanks
    const posterA = Tex.tex(Tex.poster('JAZZ', 'NIGHTLY TRIO', '#12233f', '#e8c768'), 1);
    const posterB = Tex.tex(Tex.poster('BINGO', 'EVERY EVENING', '#4a0f18', '#f0d78a'), 1);
    const pFrame = mat({ color: COL.brassDark, roughness: 0.3, metalness: 0.9 });
    [[-9.2, 2.9, posterA], [9.4, 2.9, posterB]].forEach(([px, py, t]) => {
      const fr = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.0, 0.07), pFrame);
      fr.position.set(px, py, -13.35); S.add(fr);
      const im = new THREE.Mesh(new THREE.PlaneGeometry(1.34, 1.84), mat({ map: t, roughness: 0.85 }));
      im.position.set(px, py, -13.3); S.add(im);
    });

    // wall sconces
    this.sconces = [];
    for (let i = -2; i <= 2; i++) {
      const g = new THREE.Group();
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.34, 8), mat({ color: COL.brassDark, metalness: 0.9, roughness: 0.3 }));
      arm.rotation.x = Math.PI / 2.4; arm.position.set(0, 0, 0.16);
      const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.09, 0.26, 14, 1, true),
        mat({ color: 0xfff0cf, emissive: 0xffb757, emissiveIntensity: 1.6, side: THREE.DoubleSide, roughness: 0.6 }));
      sh.position.set(0, 0.14, 0.3);
      g.add(arm, sh);
      g.position.set(i * 5.2, 3.15, -13.2);
      S.add(g);
    }

    // chandeliers
    const chandMat = mat({ color: COL.brass, metalness: 1.0, roughness: 0.2, envMapIntensity: 1.6 });
    const bulbMat = mat({ color: 0xfff3d0, emissive: 0xffc879, emissiveIntensity: 2.6, roughness: 0.4 });
    this.chandeliers = [];
    [[-6.5, -4.6], [6.5, -4.6], [0, 1.6]].forEach(([cx, cz], ci) => {
      const g = new THREE.Group();
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.1, 8), chandMat);
      rod.position.y = 0.55; g.add(rod);
      const hub = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.05, 8, 24), chandMat);
      hub.rotation.x = Math.PI / 2; g.add(hub);
      const hub2 = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.035, 8, 24), chandMat);
      hub2.rotation.x = Math.PI / 2; hub2.position.y = -0.22; g.add(hub2);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const bx = Math.cos(a) * 0.5, bz = Math.sin(a) * 0.5;
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.34, 6), chandMat);
        stem.position.set(bx * 0.86, -0.16, bz * 0.86); g.add(stem);
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.075, 14, 12),
          mat({ color: 0xfff6e0, emissive: 0xffcf8a, emissiveIntensity: 3.4, roughness: 0.3 }));
        bulb.position.set(bx, -0.34, bz); g.add(bulb);
        const flame = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.13, 8), bulb.material);
        flame.position.set(bx, -0.26, bz); g.add(flame);
        // crystal drops
        const drop = new THREE.Mesh(new THREE.OctahedronGeometry(0.045, 0),
          mat({ color: 0xffffff, emissive: 0xffe6b0, emissiveIntensity: 0.6, metalness: 0.2, roughness: 0.05, transparent: true, opacity: 0.85 }));
        drop.position.set(bx * 1.24, -0.52, bz * 1.24); g.add(drop);
      }
      mergeParts(g);                       // ~40 primitives -> 3 meshes
      g.position.set(cx, H - 1.7, cz);
      S.add(g);
      this.chandeliers.push(g);
      this.movers.push({ g, t: Math.random() * 6, fn: (o, t) => { o.g.rotation.y = t * 0.06 + o.t; o.g.rotation.z = Math.sin(t * 0.7 + o.t) * 0.008; } });
    });

    // stage riser under the bandstand
    const rise = new THREE.Mesh(new THREE.BoxGeometry(11, 0.34, 5.4), woodMat(Tex.wood({ base: '#4a2c18', planks: 0, seed: 77 }), 0.5, 0.05, 2));
    rise.position.set(0, 0.17, -5.6);
    rise.receiveShadow = true; rise.castShadow = true;
    S.add(rise);
    const riseTr = new THREE.Mesh(new THREE.BoxGeometry(11.2, 0.06, 5.6), mat({ color: COL.brass, metalness: 0.95, roughness: 0.28 }));
    riseTr.position.set(0, 0.345, -5.6); S.add(riseTr);
  }

  /* ------------------------------------------------------------------ bar -- */
  buildBar() {
    const S = this.scene;
    const bx = 11.4, bz = -1.0;
    const counter = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.12, 7.4), woodMat(Tex.wood({ base: '#4d2c17', seed: 88, planks: 0, grain: 1.4 }), 0.28, 0.12, 2));
    counter.position.set(bx, 1.12, bz); counter.castShadow = true; counter.receiveShadow = true; S.add(counter);
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.06, 7.2), woodMat(Tex.wood({ base: '#3a2314', seed: 91 }), 0.55, 0.06, 2));
    body.position.set(bx + 0.1, 0.53, bz); body.castShadow = true; S.add(body);
    const brassRail = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 7.4, 12), mat({ color: COL.brass, metalness: 1, roughness: 0.18 }));
    brassRail.rotation.x = Math.PI / 2; brassRail.position.set(bx - 1.05, 1.0, bz); S.add(brassRail);
    for (const zz of [-3.2, 0.2, 3.4]) {
      const sup = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 8), mat({ color: COL.brass, metalness: 1, roughness: 0.25 }));
      sup.position.set(bx - 1.0, 0.55, bz - 0.1 + zz * 0.85); sup.rotation.z = 0.1; S.add(sup);
    }

    // back bar: shelves, mirror, bottles, glasses
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.0, 8.0), woodMat(Tex.wood({ base: '#2c1a10', seed: 101 }), 0.6, 0.05, 2));
    back.position.set(12.7, 2.0, bz); S.add(back);
    const mirrorT = Tex.tex(Tex.brass(777), 1);
    const mirror = new THREE.Mesh(new THREE.PlaneGeometry(7.4, 2.0), mat({ color: 0x9fb3c8, metalness: 1.0, roughness: 0.09, envMapIntensity: 1.5 }));
    mirror.position.set(12.5, 2.5, bz); mirror.rotation.y = -Math.PI / 2; S.add(mirror);
    const bottleCols = [0x2f5a2a, 0x6b3a12, 0x7a1d22, 0x1e3f63, 0x5a4a1a, 0x3b2a52, 0xa8802a];
    for (let row = 0; row < 2; row++) {
      const shelf = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.06, 7.6), mat({ color: 0x2a1a10, roughness: 0.5 }));
      shelf.position.set(12.2, 1.45 + row * 0.62, bz); S.add(shelf);
      for (let i = 0; i < 11; i++) {
        const col = bottleCols[Math.floor(Math.random() * bottleCols.length)];
        const hgt = 0.26 + Math.random() * 0.22;
        const bt = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.075, hgt, 12),
          mat({ color: col, roughness: 0.12, metalness: 0.05, transparent: true, opacity: 0.86, emissive: col, emissiveIntensity: 0.06 }));
        bt.position.set(12.14 + Math.random() * 0.14, 1.48 + row * 0.62 + hgt / 2, bz - 3.5 + i * 0.45);
        S.add(bt);
        const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.03, 0.16, 8), bt.material);
        neck.position.set(bt.position.x, bt.position.y + hgt / 2 + 0.07, bt.position.z); S.add(neck);
      }
    }
    // glasses on the counter
    for (let i = 0; i < 7; i++) {
      const g = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.042, 0.14, 10, 1, true),
        mat({ color: 0xdff0ff, roughness: 0.06, metalness: 0.1, transparent: true, opacity: 0.4, side: THREE.DoubleSide }));
      g.position.set(bx - 0.3 + Math.random() * 0.5, 1.25, bz - 3 + i * 1.0);
      S.add(g);
    }
    // bar stools
    const stoolSeat = mat({ map: Tex.tex(Tex.velvet('#5c1220', 5), 1), roughness: 0.9 });
    for (let i = 0; i < 4; i++) {
      const g = new THREE.Group();
      const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.16, 18), stoolSeat);
      seat.position.y = 0.92; seat.castShadow = true; g.add(seat);
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.9, 10), mat({ color: 0x2a2018, metalness: 0.7, roughness: 0.4 }));
      leg.position.y = 0.45; g.add(leg);
      const foot = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.02, 6, 16), mat({ color: 0x2a2018, metalness: 0.8, roughness: 0.3 }));
      foot.rotation.x = Math.PI / 2; foot.position.y = 0.22; g.add(foot);
      g.position.set(bx - 1.55, 0, bz - 2.6 + i * 1.7);
      S.add(g);
    }
    // bartender (bust behind the bar)
    this.bartender = this.makePerson({ suit: 0x1b1b24, shirt: 0xf2f2f2, skin: 0xb07850, hat: false });
    this.bartender.position.set(12.05, 0, bz + 1.4);
    this.bartender.rotation.y = -Math.PI / 2 - 0.4;
    this.bartender.scale.setScalar(1.02);
    S.add(this.bartender);
    const bd = this.bartender.userData;
    this.movers.push({
      t: 0, fn: (o, t) => {
        const s = Math.sin(t * 0.9);
        bd.armR.rotation.x = -0.5 + s * 0.42;
        bd.armL.rotation.x = -0.3 + Math.sin(t * 0.9 + 1.7) * 0.18;
        o.head.rotation.y = Math.sin(t * 0.35) * 0.5;
        bd.shake.visible = Math.sin(t * 3.1) > 0.55;
        if (bd.shake.visible) { bd.shake.position.y = 1.28 + Math.abs(Math.sin(t * 8)) * 0.16; bd.shake.rotation.z = Math.sin(t * 9) * 0.5; }
      }
    });
    // cocktail shaker prop
    const shaker = new THREE.Group();
    const bodyS = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.24, 14), mat({ color: 0xd8dde2, metalness: 1, roughness: 0.16 }));
    const capS = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.09, 14), mat({ color: 0xc8ced4, metalness: 1, roughness: 0.2 }));
    capS.position.y = 0.16; shaker.add(bodyS, capS);
    shaker.position.set(12.05, 1.32, bz + 1.15);
    S.add(shaker); bd.shake = shaker;

    const barBox = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.2, 7.6), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0 }));
    barBox.position.set(bx, 0.6, bz); S.add(barBox);
  }

  /* --------------------------------------------------- low-poly people ----- */
  makePerson(opt) {
    const o = Object.assign({ suit: 0x22252e, shirt: 0xf4f0e6, skin: 0xc08a5e, hair: 0x1a1410, seated: false, dress: false }, opt);
    const g = new THREE.Group();
    const skinM = mat({ color: o.skin, roughness: 0.72 });
    const suitM = mat({ color: o.suit, roughness: 0.78 });
    const shirtM = mat({ color: o.shirt, roughness: 0.7 });
    const hairM = mat({ color: o.hair, roughness: 0.9 });

    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.20, 0.36, 6, 14), o.dress ? mat({ color: o.shirt, roughness: 0.85 }) : suitM);
    torso.position.y = 1.12; torso.castShadow = true;
    const shirt = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.34, 0.24), shirtM);
    shirt.position.set(0, 1.16, 0.02); shirt.visible = !o.dress;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.135, 18, 14), skinM);
    head.position.y = 1.52; head.castShadow = true;
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.144, 18, 14, 0, Math.PI * 2, 0, Math.PI * 0.62), hairM);
    hair.position.y = 1.535;
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.065, 0.09, 10), skinM);
    neck.position.y = 1.39;
    g.add(torso, shirt, head, hair, neck);

    const armGeo = new THREE.CapsuleGeometry(0.052, 0.30, 4, 8);
    const armL = new THREE.Mesh(armGeo.clone().translate(0, -0.15, 0), suitM);
    const armR = new THREE.Mesh(armGeo.clone().translate(0, -0.15, 0), suitM);
    const shoulderY = 1.30;
    armL.position.set(-0.235, shoulderY, 0); armR.position.set(0.235, shoulderY, 0);
    // hands ride along with the arms so gestures read at a distance
    const handL = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), skinM);
    const handR = handL.clone();
    handL.position.set(0, -0.30, 0.02); handR.position.set(0, -0.30, 0.02);
    armL.add(handL); armR.add(handR);
    g.userData.handL = handL; g.userData.handR = handR;
    g.userData.armL = armL; g.userData.armR = armR;

    if (o.seated) {
      const lap = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.18, 0.42), o.dress ? mat({ color: o.shirt, roughness: 0.85 }) : suitM);
      lap.position.set(0, 0.62, 0.14); g.add(lap);
      const thighL = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.30, 4, 8), suitM);
      thighL.rotation.x = Math.PI / 2; thighL.position.set(-0.11, 0.64, 0.24);
      const thighR = thighL.clone(); thighR.position.x = 0.11;
      const shinL = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.44, 4, 8), suitM);
      shinL.position.set(-0.11, 0.34, 0.42);
      const shinR = shinL.clone(); shinR.position.x = 0.11;
      const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.24), mat({ color: 0x161616, roughness: 0.5 }));
      shoeL.position.set(-0.11, 0.05, 0.47);
      const shoeR = shoeL.clone(); shoeR.position.x = 0.11;
      g.add(lap, thighL, thighR, shinL, shinR, shoeL, shoeR);
      torso.position.y = 1.06; shirt.position.y = 1.10; head.position.y = 1.46; neck.position.y = 1.33;
      armL.position.y = 1.24; armR.position.y = 1.24;
    } else {
      const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.62, 4, 8), suitM);
      legL.position.set(-0.10, 0.44, 0);
      const legR = legL.clone(); legR.position.x = 0.10;
      const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.26), mat({ color: 0x161616, roughness: 0.5 }));
      shoeL.position.set(-0.10, 0.04, 0.04);
      const shoeR = shoeL.clone(); shoeR.position.x = 0.10;
      g.add(legL, legR, shoeL, shoeR);
    }
    // bow tie for the gents
    if (!o.dress) {
      const bow = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.045, 0.05), mat({ color: 0x8d1620, roughness: 0.6 }));
      bow.position.set(0, (o.seated ? 1.30 : 1.37), 0.10);
      g.add(bow);
    }
    // the head carries its own hair so head turns look right
    g.remove(hair);
    head.add(hair);
    hair.position.set(0, o.seated ? 0.015 : 0.015, 0);
    g.add(head, armL, armR);
    // bake the static bodywork down to a couple of meshes
    mergeParts(g, [armL, armR, head]);
    g.userData.head = head;
    g.userData.hair = hair;
    g.traverse((c) => { if (c.isMesh) { c.castShadow = true; } });
    return g;
  }

  /* ------------------------------------------------------------- bandstand -- */
  buildBandstand() {
    const S = this.scene;
    // ---- grand piano
    const piano = new THREE.Group();
    const black = mat({ color: 0x0b0b0d, roughness: 0.12, metalness: 0.25, envMapIntensity: 1.5, clearcoat: 1 });
    const bodyShape = new THREE.Shape();
    bodyShape.moveTo(-0.75, -0.85);
    bodyShape.lineTo(0.75, -0.85);
    bodyShape.lineTo(0.75, 0.75);
    bodyShape.lineTo(-0.18, 1.15);
    bodyShape.quadraticCurveTo(-0.62, 1.30, -0.75, 0.85);
    bodyShape.lineTo(-0.75, -0.85);
    const bodyGeo = new THREE.ExtrudeGeometry(bodyShape, { depth: 0.30, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.02, bevelSegments: 3, steps: 1 });
    const body = new THREE.Mesh(bodyGeo, black);
    body.rotation.x = -Math.PI / 2;
    body.position.y = 0.95;
    body.castShadow = true; body.receiveShadow = true;
    piano.add(body);
    // lid propped open
    const lid = new THREE.Mesh(bodyGeo, black);
    lid.rotation.x = -Math.PI / 2; lid.rotation.z = 0.0;
    lid.position.set(0, 1.26, 0);
    lid.scale.set(0.97, 1, 1);
    lid.rotation.y = -0.52;
    lid.position.x += -0.07; lid.position.z += -0.10;
    piano.add(lid);
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.62, 8), mat({ color: 0x111111, roughness: 0.4 }));
    stick.position.set(0.42, 1.28, 0.16); stick.rotation.z = 0.32; piano.add(stick);
    // legs & pedals
    const legMat = mat({ color: 0x0a0a0c, roughness: 0.25, metalness: 0.2 });
    [[-0.6, -0.72], [0.6, -0.72], [0.55, 0.72]].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.06, 0.98, 12), legMat);
      leg.position.set(lx, 0.49, lz); leg.castShadow = true; piano.add(leg);
    });
    const lyre = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.36, 0.07), legMat);
    lyre.position.set(0.12, 0.42, 1.0); piano.add(lyre);
    // keys
    const kbMat = mat({ color: 0xf6f4ee, roughness: 0.3 });
    const keys = new THREE.Mesh(new THREE.BoxGeometry(1.42, 0.035, 0.17), kbMat);
    keys.position.set(0.04, 0.99, 1.06); piano.add(keys);
    const woodLip = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.07, 0.24), mat({ color: 0x120f0d, roughness: 0.35 }));
    woodLip.position.set(0.04, 0.965, 1.0); piano.add(woodLip);
    const sharps = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.03, 0.10), mat({ color: 0x0a0a0a, roughness: 0.3 }));
    // music desk + sheet
    const desk = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.3, 0.03), mat({ color: 0x0e0c0b, roughness: 0.5 }));
    desk.position.set(0.04, 1.22, 0.86); desk.rotation.x = -0.35; piano.add(desk);
    const sheetT = (() => {
      const { c, x, w, h } = Tex.cnv(256, 340);
      x.fillStyle = '#f7f3e4'; x.fillRect(0, 0, w, h);
      x.strokeStyle = '#333'; x.lineWidth = 1;
      for (let s = 0; s < 12; s++) {
        const y = 40 + s * 22;
        x.beginPath(); x.moveTo(34, y); x.lineTo(w - 34, y); x.stroke();
      }
      x.fillStyle = '#111';
      for (let i = 0; i < 90; i++) {
        const lx = 36 + Math.random() * (w - 80), ly = 32 + Math.random() * 250;
        x.beginPath(); x.ellipse(lx, ly, 4.2, 3, -0.4, 0, Math.PI * 2); x.fill();
        if (Math.random() < 0.3) x.fillRect(lx - 0.7, ly - 22, 1.4, 22);
      }
      x.fillStyle = '#7a1a20';
      x.font = '700 22px Georgia, serif';
      x.fillText('Blue Lounge', 30, 24);
      return c;
    })();
    const sheet = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.60), mat({ map: Tex.tex(sheetT), roughness: 0.9, side: THREE.DoubleSide }));
    sheet.position.set(0.04, 1.36, 0.795); sheet.rotation.x = -0.35; piano.add(sheet);
    // fallboard name plate
    const plate = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.02), mat({ color: COL.brass, metalness: 1, roughness: 0.2 }));
    plate.position.set(0.04, 1.0, 0.9); piano.add(plate);

    piano.position.set(-7.2, 0.34, -6.0);
    piano.rotation.y = 0.62;
    S.add(piano);
    this.piano = piano;

    // ---- pianist with animating hands
    const pianist = this.makePerson({ suit: 0x14161f, shirt: 0xf6f2e6, skin: 0xa8764c, hair: 0x120f0c, seated: true });
    pianist.position.set(-6.15, 0.34, -5.15);
    pianist.rotation.y = 0.62 + Math.PI;
    S.add(pianist);
    const pd = pianist.userData;
    // give the pianist real forearms
    const sleeveM = mat({ color: 0x14161f, roughness: 0.8 });
    const fore = new THREE.CapsuleGeometry(0.045, 0.26, 4, 8);
    const foreL = new THREE.Mesh(fore, sleeveM), foreR = new THREE.Mesh(fore, sleeveM);
    const handL = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.05, 0.14), mat({ color: 0xa8764c, roughness: 0.7 }));
    const handR = handL.clone();
    const pivotL = new THREE.Group(), pivotR = new THREE.Group();
    pivotL.position.set(-0.20, 1.22, 0.16); pivotR.position.set(0.20, 1.22, 0.16);
    foreL.position.set(0, -0.14, 0.12); foreR.position.set(0, -0.14, 0.12);
    handL.position.set(0, -0.28, 0.30); handR.position.set(0, -0.28, 0.30);
    pivotL.add(foreL, handL); pivotR.add(foreR, handR);
    pianist.add(pivotL, pivotR);
    this.pianist = pianist;
    this.pianistHands = { pivotL, pivotR };
    this.movers.push({
      t: 0, fn: (o, t) => {
        // hands roam the keyboard with fast jazz runs
        const beat = t * 2.1;
        const roamL = Math.sin(beat * 0.83) * 0.16 - 0.06;
        const roamR = Math.sin(beat * 0.61 + 1.2) * 0.17 + 0.10;
        pivotL.position.x = -0.20 + roamL;
        pivotR.position.x = 0.10 + roamR;
        pivotL.position.z = 0.16 + Math.sin(beat * 1.7) * 0.045;
        pivotR.position.z = 0.16 + Math.cos(beat * 1.31) * 0.04;
        handL.position.y = -0.28 + Math.abs(Math.sin(beat * 3.3)) * 0.03;
        handR.position.y = -0.28 + Math.abs(Math.sin(beat * 2.7 + 0.4)) * 0.03;
        const nod = Math.sin(t * 1.35) * 0.05;
        pd.head.rotation.x = 0.22 + nod;
        pianist.position.y = 0.34 + Math.abs(Math.sin(t * 2.1)) * 0.006;
      }
    });

    // ---- upright bass + bassist
    const bassist = this.makePerson({ suit: 0x1d2430, shirt: 0xefe9dc, skin: 0x8a5a36, hair: 0x0f0d0b, seated: false });
    bassist.position.set(-4.6, 0.34, -6.6);
    bassist.rotation.y = 1.15;
    S.add(bassist);
    const bassGroup = new THREE.Group();
    const bassWood = mat({ map: Tex.tex(Tex.wood({ base: '#5a2f16', seed: 313, grain: 1.6 }), 1), roughness: 0.35, metalness: 0.05 });
    const upper = new THREE.Mesh(new THREE.SphereGeometry(0.30, 20, 16, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.65), bassWood);
    upper.position.y = 0.42; upper.scale.set(0.92, 1.05, 0.55);
    const lower = new THREE.Mesh(new THREE.SphereGeometry(0.42, 20, 16), bassWood);
    lower.position.y = 0.40; lower.scale.set(0.95, 1.25, 0.6);
    const waist = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.30, 0.16, 16), bassWood);
    waist.position.y = 0.42; waist.scale.z = 0.6;
    const neck = new THREE.Mesh(new THREE.BoxGeometry(0.09, 1.05, 0.07), mat({ color: 0x3a2410, roughness: 0.5 }));
    neck.position.y = 1.22;
    const scroll = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.022, 6, 12, Math.PI * 1.6), mat({ color: 0x3a2410, roughness: 0.5 }));
    scroll.position.y = 1.78; scroll.rotation.x = Math.PI / 2;
    const fb = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.9, 0.03), mat({ color: 0x140f0a, roughness: 0.4 }));
    fb.position.set(0, 1.20, 0.045);
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.07, 0.04), mat({ color: 0x2a1a0e, roughness: 0.5 }));
    bridge.position.set(0, 0.62, 0.13);
    bassGroup.add(upper, lower, waist, neck, scroll, fb, bridge);
    const stringMat = mat({ color: 0xd8d8d8, metalness: 1, roughness: 0.3 });
    for (let i = 0; i < 4; i++) {
      const st = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 1.5, 5), stringMat);
      st.position.set(-0.032 + i * 0.021, 1.25, 0.06);
      bassGroup.add(st);
    }
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.2, 8), mat({ color: 0x140f0a }));
    tail.position.set(0, 0.16, 0.06); tail.rotation.x = Math.PI;
    bassGroup.add(tail);
    mergeParts(bassGroup);
    bassGroup.position.set(-4.6, 0.34, -6.6);
    bassGroup.rotation.y = 1.15;
    S.add(bassGroup);
    const bd = bassist.userData;
    this.movers.push({
      t: 0, fn: (o, t) => {
        const w = Math.sin(t * 1.55);
        bd.armR.rotation.x = -0.75 + w * 0.42;
        bd.armL.rotation.x = -0.35 + Math.sin(t * 1.55 + 2.4) * 0.3;
        bd.head.rotation.y = -0.16 + Math.sin(t * 0.42) * 0.22;
        bd.head.rotation.x = 0.12;
        bassist.rotation.z = w * 0.014;
        bassGroup.rotation.z = -w * 0.01;
        bassGroup.position.y = 0.34 + Math.abs(w) * 0.004;
      }
    });

    // ---- drum kit + drummer with brushes
    const drumShell = (r, hgt, col) => {
      const g = new THREE.Group();
      const shellM = mat({ color: col, roughness: 0.22, metalness: 0.15, envMapIntensity: 1.2 });
      const sh = new THREE.Mesh(new THREE.CylinderGeometry(r, r, hgt, 26, 1, true), shellM);
      const top = new THREE.Mesh(new THREE.CircleGeometry(r, 26), mat({ color: 0xf2ece0, roughness: 0.55 }));
      top.rotation.x = -Math.PI / 2; top.position.y = hgt / 2 + 0.004;
      const hoopT = new THREE.Mesh(new THREE.TorusGeometry(r, 0.014, 6, 26), mat({ color: 0xd8dde3, metalness: 1, roughness: 0.2 }));
      hoopT.rotation.x = Math.PI / 2; hoopT.position.y = hgt / 2;
      const hoopB = hoopT.clone(); hoopB.position.y = -hgt / 2;
      g.add(sh, top, hoopT, hoopB);
      return g;
    };
    const dusk = drumShell(0.26, 0.34, 0x8e1720);   // kick
    dusk.rotation.x = Math.PI / 2; dusk.rotation.z = Math.PI / 2;
    dusk.position.set(7.0, 0.34 + 0.30, -5.7);
    S.add(dusk);
    const kickHead = new THREE.Mesh(new THREE.CircleGeometry(0.25, 24), mat({ color: 0xf0e8d8, roughness: 0.5 }));
    kickHead.position.set(7.0 - 0.001, 0.64, -5.7 - 0.31); kickHead.rotation.y = Math.PI; S.add(kickHead);
    const snare = drumShell(0.20, 0.16, 0xb9c0c7);
    snare.position.set(6.20, 0.34 + 0.62, -5.35); S.add(snare);
    const snareStand = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.62, 8), mat({ color: 0x9aa2aa, metalness: 1, roughness: 0.3 }));
    snareStand.position.set(6.20, 0.34 + 0.30, -5.35); S.add(snareStand);
    const tom = drumShell(0.19, 0.26, 0x8e1720);
    tom.position.set(6.75, 0.34 + 0.92, -5.9); tom.rotation.x = -0.28; S.add(tom);
    const tomS = drumShell(0.15, 0.22, 0x8e1720);
    tomS.position.set(7.35, 0.34 + 0.98, -5.95); tomS.rotation.x = -0.22; S.add(tomS);
    const tomStand = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.55, 8), mat({ color: 0x9aa2aa, metalness: 1, roughness: 0.3 }));
    tomStand.position.set(7.05, 0.34 + 0.6, -5.9); S.add(tomStand);
    // hi-hat
    const hh = new THREE.Group();
    for (let i = 0; i < 2; i++) {
      const cym = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.006, 26), mat({ color: COL.brass, metalness: 1, roughness: 0.22, envMapIntensity: 1.6 }));
      cym.position.y = i * 0.035; hh.add(cym);
    }
    const hhStand = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.95, 8), mat({ color: 0xa8b0b8, metalness: 1, roughness: 0.3 }));
    hhStand.position.y = -0.48; hh.add(hhStand);
    hh.position.set(5.55, 0.34 + 0.95, -5.35); S.add(hh);
    // ride cymbal
    const ride = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.30, 0.008, 32), mat({ color: COL.brass, metalness: 1, roughness: 0.18, envMapIntensity: 1.8 }));
    ride.position.set(8.0, 0.34 + 1.02, -5.5);
    ride.rotation.z = 0.16;
    S.add(ride);
    const rideStand = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.02, 8), mat({ color: 0xa8b0b8, metalness: 1, roughness: 0.3 }));
    rideStand.position.set(8.0, 0.34 + 0.51, -5.5); S.add(rideStand);
    // throne + drummer
    const throne = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.20, 0.09, 18), mat({ color: 0x1a1a20, roughness: 0.6 }));
    throne.position.set(7.2, 0.34 + 0.56, -4.85); S.add(throne);
    const throneLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, 0.52, 10), mat({ color: 0x2a2a30, metalness: 0.8, roughness: 0.35 }));
    throneLeg.position.set(7.2, 0.34 + 0.27, -4.85); S.add(throneLeg);
    const drummer = this.makePerson({ suit: 0x101018, shirt: 0xe8e2d4, skin: 0x6f4a2c, hair: 0x0c0a09, seated: true });
    drummer.position.set(7.2, 0.34 + 0.16, -4.85);
    drummer.rotation.y = Math.PI + 0.24;
    S.add(drummer);
    const dd = drummer.userData;
    // brush sticks in the drummer's hands
    const brushGeo = new THREE.CylinderGeometry(0.008, 0.006, 0.42, 6);
    const brushM = mat({ color: 0xb9a06a, metalness: 0.6, roughness: 0.4 });
    const brushL = new THREE.Mesh(brushGeo, brushM), brushR = new THREE.Mesh(brushGeo, brushM);
    brushL.position.set(-0.02, 0.20, 0.16); brushR.position.set(-0.02, 0.20, 0.16);
    dd.armL.add(brushL); dd.armR.add(brushR);
    brushL.rotation.x = 0.5; brushR.rotation.x = 0.4;
    this.drummer = drummer;
    this.movers.push({
      t: 0, fn: (o, t) => {
        const b = t * 2.2;
        dd.armR.rotation.x = -0.95 + Math.sin(b * 2.1) * 0.30;
        dd.armR.rotation.z = -0.25 + Math.cos(b * 2.1) * 0.22;
        dd.armL.rotation.x = -0.8 + Math.sin(b * 2.1 + 0.7) * 0.26;
        dd.armL.rotation.z = 0.22 + Math.cos(b * 2.1 + 0.6) * 0.2;
        dd.head.rotation.x = 0.1 + Math.sin(b) * 0.07;
        dd.head.rotation.y = Math.sin(b * 0.5) * 0.22;
        const sw = Math.sin(b * 2.1) * 0.5 + 0.5;
        drummer.position.y = 0.34 + 0.16 + sw * 0.008;
        ride.rotation.z = 0.16 + Math.sin(b * 2.1) * 0.02;
      }
    });

    // ---- bandstand mood lights + mic stands
    const sp = new THREE.SpotLight(0xffbe72, 120, 16, 0.55, 0.6, 2);
    sp.position.set(-4.5, 5.0, -5.0);
    sp.target.position.set(-6.5, 0.9, -6.0);
    S.add(sp); S.add(sp.target);
    const sp2 = new THREE.SpotLight(0x9fd0ff, 70, 16, 0.6, 0.7, 2);
    sp2.position.set(7.5, 5.0, -5.0);
    sp2.target.position.set(7.0, 0.8, -5.6);
    S.add(sp2); S.add(sp2.target);
    const pianoLamp = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 10), mat({ color: 0xfff0cc, emissive: 0xffc266, emissiveIntensity: 4 }));
    pianoLamp.position.set(-6.4, 1.42, -5.75); S.add(pianoLamp);
  }

  /* -------------------------------------------------------------- audience -- */
  buildAudience() {
    const S = this.scene;
    const spots = [
      [-11.7, -5.6], [-11.5, -1.4], [-11.8, 2.6],
      [11.3, -8.4], [11.5, -4.6],
      [-4.6, 6.6], [1.2, 7.0], [5.9, 6.5],
      [-8.9, 1.2], [-8.7, -3.2]
    ];
    const suits = [0x1b1f2b, 0x2a1f2a, 0x14202a, 0x33222a, 0x1d1a24, 0x232b1e];
    const skins = [0xc08a5e, 0xa8764c, 0x8a5a36, 0xdcae82, 0x6f4a2c];
    const drMat = mat({ map: Tex.tex(Tex.velvet('#4b0f1a', 21), 1), roughness: 0.88 });
    const tblW = mat({ color: 0x3a2417, roughness: 0.35, metalness: 0.1, envMapIntensity: 0.9 });
    this.tableGroups = [];
    spots.forEach(([x, z], i) => {
      const g = new THREE.Group();
      // round table
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 0.07, 24), tblW);
      top.position.y = 0.74; top.castShadow = true; top.receiveShadow = true; g.add(top);
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.10, 0.7, 12), mat({ color: 0x2a1c12, metalness: 0.6, roughness: 0.35 }));
      ped.position.y = 0.37; g.add(ped);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.34, 0.04, 16), mat({ color: 0x2a1c12, metalness: 0.6, roughness: 0.4 }));
      base.position.y = 0.03; g.add(base);
      const cloth = new THREE.Mesh(new THREE.CylinderGeometry(0.60, 0.62, 0.03, 24), mat({ color: 0x2b1c30, roughness: 0.93 }));
      cloth.position.y = 0.70; g.add(cloth);
      // candle + glow
      const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.09, 10), mat({ color: 0xf3ead2, roughness: 0.6 }));
      candle.position.set(0.2, 0.82, 0.06); g.add(candle);
      const flame = new THREE.Mesh(new THREE.SphereGeometry(0.026, 10, 8), mat({ color: 0xffe2a0, emissive: 0xffa83c, emissiveIntensity: 6 }));
      flame.position.set(0.2, 0.88, 0.06); flame.scale.y = 1.6; g.add(flame);
      flame.userData.keep = true;              // keeps its little candle flicker
      this.movers.push({ i, t: Math.random() * 9, fn: (o, t) => { flame.scale.setScalar(1 + Math.sin(t * 9 + o.i) * 0.12); } });
      // drinks
      for (let d0 = 0; d0 < 2; d0++) {
        const tumbler = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.032, 0.1, 10, 1, true),
          mat({ color: 0xdff0ff, roughness: 0.07, metalness: 0.1, transparent: true, opacity: 0.42, side: THREE.DoubleSide }));
        tumbler.position.set(-0.26 + d0 * 0.5, 0.82, -0.22 + d0 * 0.1); g.add(tumbler);
        const liq = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.028, 0.06, 10),
          mat({ color: d0 ? 0xc08a2e : 0x8a2a1a, roughness: 0.15, metalness: 0.05, transparent: true, opacity: 0.85 }));
        liq.position.set(tumbler.position.x, 0.79, tumbler.position.z); g.add(liq);
      }
      // chairs + people
      const nPeople = 2 + (i % 3 === 0 ? 1 : 0);
      for (let p = 0; p < nPeople; p++) {
        const ang = (p / nPeople) * Math.PI * 2 + i * 0.7;
        const px = Math.cos(ang) * 0.92, pz = Math.sin(ang) * 0.92;
        const person = this.makePerson({
          suit: suits[(i + p) % suits.length],
          shirt: p % 2 ? 0xe9dfc8 : 0xdfe6ee,
          skin: skins[(i * 2 + p) % skins.length],
          hair: [0x1a1410, 0x2b1b10, 0x4a3423, 0x0f0d0b][(i + p) % 4],
          seated: true
        });
        const s = 0.94 + ((i + p) % 3) * 0.05;
        person.scale.setScalar(s);
        person.position.set(px * 1.12, 0, pz * 1.12);
        person.rotation.y = Math.atan2(-px, -pz);
        g.add(person);
        const ud = person.userData;
        this.movers.push({
          t: Math.random() * 6, fn: (o, t) => {
            person.position.y = Math.abs(Math.sin(t * 1.2 + o.t)) * 0.012;
            person.rotation.y += Math.sin(t * 0.35 + o.t) * 0.0006;
            ud.head.rotation.y = Math.sin(t * 0.55 + o.t) * 0.42;
            ud.head.rotation.z = Math.sin(t * 0.9 + o.t * 2) * 0.05;
            ud.armR.rotation.x = -0.35 + Math.sin(t * 1.1 + o.t) * 0.16;
            ud.armL.rotation.x = -0.3 + Math.sin(t * 0.9 + o.t + 1) * 0.12;
          }
        });
        // chair
        const chairM = mat({ color: 0x241a12, roughness: 0.6, metalness: 0.15 });
        const seat = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.06, 0.42), chairM);
        seat.position.set(px * 1.36, 0.45, pz * 1.36); g.add(seat);
        const backr = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.5, 0.06), chairM);
        backr.position.set(px * 1.36 + Math.cos(person.rotation.y) * 0.0, 0.72, pz * 1.36 + 0.2);
        g.add(backr);
        for (const [lx, lz] of [[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]]) {
          const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.45, 6), chairM);
          leg.position.set(px * 1.36 + lx, 0.22, pz * 1.36 + lz); g.add(leg);
        }
      }
      mergeParts(g);                            // table + chairs + glassware bake down
      g.position.set(x, 0, z);
      S.add(g);
      this.tableGroups.push(g);
    });
  }

  /* ------------------------------------------------------- player's tables -- */
  buildTables() {
    const S = this.scene;
    // The player's own console table (foreground) — card rests here
    const g = new THREE.Group();
    const woodT = Tex.tex(Tex.wood({ base: '#4a2a15', seed: 606, grain: 1.3 }), 1);
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 0.09, 30), mat({ map: woodT, roughness: 0.45, metalness: 0.06, envMapIntensity: 0.5 }));
    top.position.y = 0.78; top.castShadow = true; top.receiveShadow = true; g.add(top);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.03, 8, 40), mat({ color: COL.brass, metalness: 1, roughness: 0.22 }));
    rim.rotation.x = Math.PI / 2; rim.position.y = 0.775; g.add(rim);
    const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.16, 0.74, 14), mat({ color: 0x2a1a10, metalness: 0.7, roughness: 0.32 }));
    ped.position.y = 0.38; g.add(ped);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 0.05, 20), mat({ color: 0x2a1a10, metalness: 0.7, roughness: 0.36 }));
    base.position.y = 0.03; g.add(base);
    g.position.set(-2.52, 0, 4.20);
    S.add(g);
    this.playerTable = g;

    // velvet chair pushed back so it doesn't block the view
    const chair = new THREE.Group();
    const seatM = mat({ map: Tex.tex(Tex.velvet('#4d1220', 9), 1), roughness: 0.9 });
    const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.13, 22), seatM);
    seat.position.y = 0.46; chair.add(seat);
    const back = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.9, 22, 1, true, -0.9, 1.8), seatM);
    back.material = seatM.clone(); back.material.side = THREE.DoubleSide;
    back.position.y = 0.82; chair.add(back);
    const cl = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.45, 10), mat({ color: 0x2a1c12, metalness: 0.7, roughness: 0.35 }));
    cl.position.y = 0.22; chair.add(cl);
    chair.position.set(-1.75, 0, 6.35);
    chair.rotation.y = -0.42;
    S.add(chair);
    this.playerChair = chair;
  }

  /* ----------------------------------------------------------- bingo rig ---- */
  buildBingoRig() {
    const RS = this.scene;
    // The whole caller's podium is raised 0.55m on a dark plinth so the cage,
    // tray and current-ball pedestal all sit clearly ABOVE the player's card
    // in the camera frame (nothing important gets occluded).
    const RP = new THREE.Group();
    RP.position.set(1.15, 0.55, 0);
    RS.add(RP);
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(8.1, 0.56, 2.9),
      mat({ map: Tex.tex(Tex.wood({ base: '#2c1a10', seed: 555, planks: 0 }), 2), roughness: 0.5, metalness: 0.1 }));
    plinth.position.set(1.15, 0.27, -0.4);
    plinth.receiveShadow = true;
    RS.add(plinth);
    const plinthTrim = new THREE.Mesh(new THREE.BoxGeometry(8.18, 0.05, 2.98), mat({ color: COL.brass, metalness: 1, roughness: 0.26 }));
    plinthTrim.position.set(1.15, 0.55, -0.4);
    RS.add(plinthTrim);
    const S = RP;                       // everything below is in podium space
    const rig = new THREE.Group();
    rig.position.x = 1.15;
    // master table (felt-topped, curved front) holding cage, chute, tray
    const tblM = mat({ map: Tex.tex(Tex.wood({ base: '#452715', seed: 424, grain: 1.1 }), 1), roughness: 0.48, metalness: 0.05, envMapIntensity: 0.5 });
    const top = new THREE.Mesh(new THREE.BoxGeometry(7.6, 0.14, 2.6), tblM);
    top.position.y = 1.0; top.castShadow = true; top.receiveShadow = true; rig.add(top);
    const feltT = new THREE.Mesh(new THREE.BoxGeometry(7.0, 0.03, 2.2), mat({ map: Tex.tex(Tex.felt('#1d3a2b', 71), 2), roughness: 0.96 }));
    feltT.position.y = 1.08; feltT.receiveShadow = true; rig.add(feltT);
    const apron = new THREE.Mesh(new THREE.BoxGeometry(7.6, 0.62, 2.6), mat({ color: 0x2f1a0e, roughness: 0.55 }));
    apron.position.y = 0.62; rig.add(apron);
    // brass corner trim
    const trim = new THREE.Mesh(new THREE.BoxGeometry(7.68, 0.05, 2.68), mat({ color: COL.brass, metalness: 1, roughness: 0.24 }));
    trim.position.y = 0.94; rig.add(trim);
    // legs
    for (const [lx, lz] of [[-3.5, -1.05], [3.5, -1.05], [-3.5, 1.05], [3.5, 1.05]]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.06, 0.95, 12), mat({ color: 0x2a1a10, metalness: 0.5, roughness: 0.4 }));
      leg.position.set(lx, 0.48, lz); leg.castShadow = true; rig.add(leg);
    }
    rig.position.set(0, 0, -0.4);
    S.add(rig);
    this.rig = rig;

    /* ---- the brass cage (the star of the show) */
    const cage = new THREE.Group();
    const brassM = mat({ map: Tex.tex(Tex.brass(12345), 1), color: 0xffffff, metalness: 1.0, roughness: 0.18, envMapIntensity: 1.7 });
    const cageR = 0.46;
    const bars = 22;
    for (let i = 0; i < bars; i++) {
      const a = (i / bars) * Math.PI * 2;
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 1.0, 8), brassM);
      bar.position.set(Math.cos(a) * cageR, 0, Math.sin(a) * cageR);
      cage.add(bar);
    }
    for (const yy of [-0.5, -0.16, 0.16, 0.5]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(cageR, 0.018, 8, 40), brassM);
      ring.rotation.x = Math.PI / 2; ring.position.y = yy;
      cage.add(ring);
    }
    const cageTop = new THREE.Mesh(new THREE.CylinderGeometry(cageR + 0.03, cageR + 0.03, 0.06, 30), brassM);
    cageTop.position.y = 0.53; cage.add(cageTop);
    const cageTopDome = new THREE.Mesh(new THREE.SphereGeometry(cageR + 0.03, 30, 12, 0, Math.PI * 2, 0, Math.PI / 2), brassM);
    cageTopDome.position.y = 0.56; cageTopDome.scale.y = 0.45; cage.add(cageTopDome);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 12), brassM);
    knob.position.y = 0.80; cage.add(knob);
    const cageBase = new THREE.Mesh(new THREE.CylinderGeometry(cageR + 0.05, cageR + 0.09, 0.10, 30), brassM);
    cageBase.position.y = -0.55; cage.add(cageBase);
    const cageFloor = new THREE.Mesh(new THREE.CylinderGeometry(cageR, cageR, 0.02, 30), mat({ color: 0x1a1208, roughness: 0.5 }));
    cageFloor.position.y = -0.5; cage.add(cageFloor);
    // inner balls (visible tumbling inside when idle)
    this.innerBalls = [];
    const atl = Tex.ballAtlas();
    for (let i = 0; i < 16; i++) {
      const n = 1 + Math.floor(Math.random() * 75);
      const b = this.makeBallMesh(atl, n, 0.056);
      const a = Math.random() * Math.PI * 2, rr = Math.random() * (cageR - 0.11);
      b.position.set(Math.cos(a) * rr, -0.44 + Math.random() * 0.9, Math.sin(a) * rr);
      b.userData.vel = new THREE.Vector3((Math.random() - 0.5) * 0.5, 0, (Math.random() - 0.5) * 0.5);
      cage.add(b);
      this.innerBalls.push(b);
    }
    cage.position.set(-2.15, 1.75, 0.0);
    this.cage = cage;
    S.add(cage);
    this.ballAtlas = atl;
    // cage pedestal / gearing
    const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.26, 0.5, 18), brassM);
    ped.position.set(-2.15, 1.38, 0.0); S.add(ped);
    const gearBox = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.34), mat({ color: 0x241a10, metalness: 0.7, roughness: 0.35 }));
    gearBox.position.set(-2.15, 1.32, 0.0); S.add(gearBox);
    const crank = new THREE.Group();
    const crankArm = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.26, 0.04), mat({ color: COL.brass, metalness: 1, roughness: 0.25 }));
    crankArm.position.y = 0.13;
    const crankGrip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.12, 10), mat({ map: Tex.tex(Tex.wood({ base: '#3a1f10', seed: 5 }), 1), roughness: 0.5 }));
    crankGrip.rotation.z = Math.PI / 2; crankGrip.position.set(0.09, 0.26, 0);
    crank.add(crankArm, crankGrip);
    crank.position.set(-2.15, 1.12, 0.42);
    this.crank = crank;
    S.add(crank);

    /* ---- chute that serves the ball toward the tray */
    const chuteMat = mat({ map: Tex.tex(Tex.brass(4242), 1), metalness: 1, roughness: 0.22, envMapIntensity: 1.5 });
    const chuteTube = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.055, 10, 24, Math.PI * 0.62), chuteMat);
    chuteTube.position.set(-1.35, 1.62, 0.02);
    chuteTube.rotation.z = -0.5; chuteTube.rotation.x = 0.0;
    S.add(chuteTube);
    const chuteEnd = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.085, 0.16, 14), chuteMat);
    chuteEnd.position.set(-1.02, 1.30, 0.02);
    S.add(chuteEnd);
    this.chuteEnd = new THREE.Vector3(-1.02, 1.22, 0.02);


    /* ---- the tray / flashboard rack: last 10 balls in a groove */
    const tray = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.10, 0.62), mat({ map: Tex.tex(Tex.wood({ base: '#3a1f36', seed: 909 }), 2), roughness: 0.35 }));
    tray.position.set(0.9, 1.14, 0.62);
    S.add(tray);
    const groove = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.05, 0.44), mat({ color: 0x120c08, roughness: 0.9 }));
    groove.position.set(0.9, 1.20, 0.62); S.add(groove);
    this.traySlots = [];
    for (let i = 0; i < 10; i++) {
      this.traySlots.push(new THREE.Vector3(0.9 - 2.05 + i * 0.455, 1.245, 0.62));
    }
    // rails to keep balls in place
    for (const dz of [-0.24, 0.24]) {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 4.4, 10), mat({ color: COL.brass, metalness: 1, roughness: 0.25 }));
      rail.rotation.z = Math.PI / 2;
      rail.position.set(0.9, 1.28, 0.62 + dz);
      S.add(rail);
    }

    /* ---- current-ball pedestal (big, front and centre) */
    const ped2 = new THREE.Group();
    const brassP = mat({ map: Tex.tex(Tex.brass(66), 1), metalness: 1, roughness: 0.22, envMapIntensity: 1.4 });
    const pbase = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.26, 0.10, 20), brassP);
    const ppost = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.042, 0.30, 12), mat({ color: COL.brassDark, metalness: 1, roughness: 0.3 }));
    ppost.position.y = 0.19;
    const cradle = new THREE.Mesh(new THREE.TorusGeometry(0.135, 0.022, 8, 22), brassP);
    cradle.rotation.x = Math.PI / 2; cradle.position.y = 0.325;
    ped2.add(pbase, ppost, cradle);
    ped2.position.set(3.15, 1.02, 0.55);
    S.add(ped2);
    this.ballPedestal = ped2;
    this.ballRestY = 0.325 + 0.135;

    /* ---- small "BINGO" sign on the masterboard */
    const signT = (() => {
      const { c, x, w, h } = Tex.cnv(512, 160);
      x.fillStyle = '#0a0d12'; x.fillRect(0, 0, w, h);
      x.strokeStyle = COL.brass.toString(16).padStart(6, '0'); x.lineWidth = 6; x.strokeStyle = '#d9b45a';
      x.strokeRect(10, 10, w - 20, h - 20);
      x.font = '900 84px Georgia, serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillStyle = '#ffd76a'; x.fillText('B I N G O', w / 2, h / 2 + 4);
      return c;
    })();
    const sign = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.47, 0.06), mat({ map: Tex.tex(signT), roughness: 0.4, emissive: 0xffffff, emissiveMap: Tex.tex(signT), emissiveIntensity: 0.6 }));
    sign.position.set(0.0, 0.70, 1.42);
    sign.rotation.x = 0.30;
    S.add(sign);


    /* ---- masterboard lamp strip (marquee bulbs that chase) */
    this.bulbs = [];
    const bulbGeo = new THREE.SphereGeometry(0.028, 10, 8);
    for (let i = 0; i < 16; i++) {
      const b = new THREE.Mesh(bulbGeo, mat({ color: 0xffe6b0, emissive: 0xffb84d, emissiveIntensity: 2.2 }));
      b.position.set(-3.55 + i * 0.475, 1.13, -1.22);
      S.add(b);
      this.bulbs.push(b);
    }

    /* ---- the player's own card console: a tilted reading lectern on the table,
            angled 40 deg toward the player so the card face reads perfectly ---- */
    const console3d = new THREE.Group();
    const standWood = mat({ map: Tex.tex(Tex.wood({ base: '#3c2213', seed: 700 }), 1), roughness: 0.32, metalness: 0.06 });
    const backPl = new THREE.Mesh(new THREE.BoxGeometry(1.30, 1.76, 0.055), standWood);
    backPl.position.y = 0.50;
    const lip = new THREE.Mesh(new THREE.BoxGeometry(1.30, 0.09, 0.22), standWood);
    lip.position.set(0, -0.36, 0.11); lip.rotation.x = -0.5;
    const basePl = new THREE.Mesh(new THREE.BoxGeometry(1.30, 0.06, 0.62), standWood);
    basePl.position.set(0, -0.44, 0.16);
    const brassLip = new THREE.Mesh(new THREE.BoxGeometry(1.32, 0.03, 0.05), mat({ color: COL.brass, metalness: 1, roughness: 0.22 }));
    brassLip.position.set(0, -0.32, 0.215);
    console3d.add(backPl, lip, basePl, brassLip);
    console3d.position.set(-2.52, 0.905, 3.52);
    console3d.rotation.set(0.66, 0.46, 0);
    S.add(console3d);
    this.cardStand = console3d;

    // a "DAUBER" bottle prop beside the card stand
    const dauber = new THREE.Group();
    const dBody = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.16, 12),
      mat({ color: 0xb8232f, roughness: 0.25, metalness: 0.05, transparent: true, opacity: 0.9 }));
    const dCap = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.03, 0.07, 10), mat({ color: 0x1a1a1a, roughness: 0.4 }));
    dCap.position.y = 0.115;
    dauber.add(dBody, dCap);
    dauber.position.set(-1.52, 0.87, 4.10);
    S.add(dauber);
    this.dauber = dauber;
  }

  makeBallMesh(atlas, num, radius) {
    const idx = num - 1;
    const G = atlas.grid, R = atlas.rows || 10;
    const col = idx % G, row = Math.floor(idx / G);
    const geo = new THREE.SphereGeometry(radius, 26, 20);
    const uv = geo.attributes.uv;
    // remap UVs so each ball samples its own cell of the 8x8 atlas (8x10 grid -> use 8x10)
    for (let i = 0; i < uv.count; i++) {
      const u = uv.getX(i), v = uv.getY(i);
      uv.setXY(i, (col + u) / G, 1 - (row + (1 - v)) / R);
    }
    uv.needsUpdate = true;
    const m = mat({ map: atlas.texRef || (atlas.texRef = this._atlasTex(atlas)), roughness: 0.12, metalness: 0.04, envMapIntensity: 1.1 });
    const mesh = new THREE.Mesh(geo, m);
    mesh.castShadow = true;
    mesh.userData.num = num;
    return mesh;
  }
  _atlasTex(atlas) {
    const t = new THREE.CanvasTexture(atlas.canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    return t;
  }

  /* ----------------------------------------------------- the big flashboard - */
  buildWallBoard() {
    const S = this.scene;
    this.wallBoard = new WallBoard(2048, 806);
    this.wallBoard.draw({ title: 'LUCKY LOUNGE', round: 1, patternName: 'ANY LINE', pattern: { cells: [] }, pot: 0, calledSet: new Set(), players: [] });
    this.boardTex = new THREE.CanvasTexture(this.wallBoard.canvas);
    this.boardTex.colorSpace = THREE.SRGBColorSpace;
    this.boardTex.anisotropy = 8;

    const bw = 9.4, bh = 3.7;
    // the panel is self-lit, like a real LED wall: crisp, bright, fog-exempt
    const bezel = new THREE.Mesh(new THREE.BoxGeometry(bw + 0.5, bh + 0.5, 0.24), mat({ color: 0x0b0b10, roughness: 0.4, metalness: 0.4 }));
    bezel.position.set(0.4, 3.35, -11.44);
    S.add(bezel);
    const bezelTrim = new THREE.Mesh(new THREE.BoxGeometry(bw + 0.74, bh + 0.74, 0.14), mat({ map: Tex.tex(Tex.brass(2024), 2), metalness: 1, roughness: 0.28 }));
    bezelTrim.position.set(0.4, 3.35, -11.5);
    S.add(bezelTrim);
    const scrMat = new THREE.MeshBasicMaterial({ map: this.boardTex, toneMapped: true, fog: false });
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(bw, bh), scrMat);
    scr.position.set(0.4, 3.35, -11.30);
    S.add(scr);
    this.screen = scr;
    // marquee lettering above the panel
    const marqT = (() => {
      const t = Tex.cnv(1024, 200);
      const x = t.x;
      const g = x.createLinearGradient(0, 0, 0, 200);
      g.addColorStop(0, '#7d1220'); g.addColorStop(1, '#3a0810');
      x.fillStyle = g; x.fillRect(0, 0, 1024, 200);
      x.strokeStyle = '#e9c877'; x.lineWidth = 6; x.strokeRect(12, 12, 1000, 176);
      x.font = '900 108px Georgia, serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillStyle = 'rgba(0,0,0,0.45)'; x.fillText('LUCKY LOUNGE BINGO', 516, 108);
      x.fillStyle = '#ffd76a'; x.fillText('LUCKY LOUNGE BINGO', 512, 102);
      return t.c;
    })();
    const marq = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 1.29),
      new THREE.MeshBasicMaterial({ map: Tex.tex(marqT), toneMapped: true, fog: false }));
    marq.position.set(0.4, 5.55, -11.34);
    S.add(marq);
  }

  updateWallBoard(state) {
    this.wallBoard.draw(state);
    this.boardTex.needsUpdate = true;
  }

  /* ---------------------------------------------------------------- lights -- */
  buildLights() {
    const S = this.scene;
    const hemi = new THREE.HemisphereLight(0x7a6a8a, 0x33241a, 0.5);
    S.add(hemi);
    const amb = new THREE.AmbientLight(0x453a48, 0.46);
    S.add(amb);

    // warm key from the ceiling over the player
    const key = new THREE.SpotLight(0xffcf95, 95, 24, 0.78, 0.6, 2);
    key.position.set(0.5, 5.2, 3.0);
    key.target.position.set(0, 1.0, 1.6);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0012;
    key.shadow.normalBias = 0.03;
    S.add(key); S.add(key.target);
    this.keyLight = key;

    // chandelier lights
    [[-6.5, -4.6], [6.5, -4.6], [0, 1.6]].forEach(([cx, cz]) => {
      const pl = new THREE.PointLight(0xffb46a, 26, 12, 2);
      pl.position.set(cx, 3.55, cz);
      S.add(pl);
    });

    // cyan rim from the flashboard side
    const rim = new THREE.SpotLight(0x88c8ff, 55, 20, 0.8, 0.7, 2);
    rim.position.set(1, 4.6, -9.5);
    rim.target.position.set(0, 1.0, 1.0);
    S.add(rim); S.add(rim.target);

    // reading lamp over the player's card lectern
    const cardLamp = new THREE.SpotLight(0xffd9a8, 26, 7, 0.55, 0.75, 2);
    cardLamp.position.set(-2.72, 4.15, 4.10);
    cardLamp.target.position.set(-2.72, 1.05, 3.30);
    S.add(cardLamp); S.add(cardLamp.target);
    this.cardLamp = cardLamp;
    const lampShade = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.26, 18, 1, true),
      mat({ color: 0x8e1f2c, emissive: 0x552018, emissiveIntensity: 0.6, roughness: 0.5, side: THREE.DoubleSide }));
    lampShade.position.set(-2.72, 4.45, 4.10); lampShade.rotation.x = Math.PI;
    S.add(lampShade);
    // warm bounce from the floor
    const bounce = new THREE.PointLight(0xff9a55, 10, 14, 2);
    bounce.position.set(0, 0.35, 2.0);
    S.add(bounce);

    // faint ambience spill from the LED wall, no harsh falloff blob
    const ledSpill = new THREE.PointLight(0x8fc8ff, 18, 9, 2.4);
    ledSpill.position.set(0.4, 3.0, -10.4);
    S.add(ledSpill);
    this.lightsWarm = [key, rim];
    // gentle flicker/live feel
    this.movers.push({
      t: 0, fn: (o, t) => {
        key.intensity = 95 + Math.sin(t * 3.1) * 1.8 + Math.sin(t * 7.7) * 0.9;
        ledSpill.intensity = 17 + Math.sin(t * 1.7) * 2.5;
      }
    });
  }

  /* ------------------------------------------------------------ dust motes -- */
  buildDust() {
    const S = this.scene;
    const N = 900;
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(N * 3);
    this.dustVel = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 24;
      pos[i * 3 + 1] = Math.random() * 4.4 + 0.2;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20 - 1;
      this.dustVel[i * 3] = (Math.random() - 0.5) * 0.05;
      this.dustVel[i * 3 + 1] = 0.012 + Math.random() * 0.05;
      this.dustVel[i * 3 + 2] = (Math.random() - 0.5) * 0.05;
    }
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const spriteT = (() => {
      const { c, x } = Tex.cnv(64, 64);
      const rg = x.createRadialGradient(32, 32, 1, 32, 32, 31);
      rg.addColorStop(0, 'rgba(255,236,200,1)');
      rg.addColorStop(0.4, 'rgba(255,220,170,0.35)');
      rg.addColorStop(1, 'rgba(255,220,170,0)');
      x.fillStyle = rg; x.fillRect(0, 0, 64, 64);
      return c;
    })();
    const mtl = new THREE.PointsMaterial({
      size: 0.055, map: new THREE.CanvasTexture(spriteT), transparent: true,
      depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.55, color: 0xffdcae, sizeAttenuation: true
    });
    this.dust = new THREE.Points(g, mtl);
    S.add(this.dust);
  }

  /* -------------------------------------------------------------- animation - */
  update(dt, t) {
    // animated props (band, candles, bartender, chandeliers)
    for (let i = 0; i < this.movers.length; i++) {
      const m = this.movers[i];
      try { m.fn(m, t); } catch (e) {}
    }
    // cage balls physics-ish tumble
    const spinning = this.cageSpinSpeed > 0.01;
    for (const b of this.innerBalls) {
      if (spinning) {
        b.userData.vel.x += (Math.random() - 0.5) * 0.9 * dt * this.cageSpinSpeed * 2;
        b.userData.vel.z += (Math.random() - 0.5) * 0.9 * dt * this.cageSpinSpeed * 2;
        b.userData.vel.y += 0.55 * dt * this.cageSpinSpeed;
      }
      b.userData.vel.y -= 3.2 * dt;
      b.position.addScaledVector(b.userData.vel, dt);
      const R = 0.36, cy = 0;
      const dx = b.position.x, dz = b.position.z;
      const d = Math.hypot(dx, dz);
      if (d > R) {
        const nx = dx / d, nz = dz / d;
        b.position.x = nx * R; b.position.z = nz * R;
        const dot = b.userData.vel.x * nx + b.userData.vel.z * nz;
        b.userData.vel.x -= 1.6 * dot * nx;
        b.userData.vel.z -= 1.6 * dot * nz;
      }
      const floorY = -0.44, ceilY = 0.40;
      if (b.position.y < floorY) { b.position.y = floorY; b.userData.vel.y = Math.abs(b.userData.vel.y) * 0.42; b.userData.vel.x *= 0.94; b.userData.vel.z *= 0.94; }
      if (b.position.y > ceilY) { b.position.y = ceilY; b.userData.vel.y = -Math.abs(b.userData.vel.y) * 0.4; }
      // slow lapping when idle
      b.userData.vel.multiplyScalar(1 - Math.min(0.5, dt * (spinning ? 0.55 : 2.6)));
    }
    if (this.cageSpinSpeed > 0) {
      this.cage.rotation.y += this.cageSpinSpeed * dt;
      this.cageSpinSpeed = Math.max(0, this.cageSpinSpeed - dt * (this.cageDecel || 0.55));
    }
    // marquee bulb chase on the masterboard
    if (this.bulbs) {
      for (let i = 0; i < this.bulbs.length; i++) {
        const phase = (t * 3.2 - i * 0.42) % (Math.PI * 2);
        const v = 0.4 + 0.6 * Math.max(0, Math.sin(phase));
        this.bulbs[i].material.emissiveIntensity = 0.6 + v * 2.6;
      }
    }
    // dust drift
    if (this.dust) {
      const p = this.dust.geometry.attributes.position;
      for (let i = 0; i < p.count; i++) {
        let y = p.getY(i) + this.dustVel[i * 3 + 1] * dt;
        let x = p.getX(i) + this.dustVel[i * 3] * dt + Math.sin(t * 0.3 + i) * 0.0006;
        let z = p.getZ(i) + this.dustVel[i * 3 + 2] * dt;
        if (y > 4.8) { y = 0.2; x = (Math.random() - 0.5) * 24; z = (Math.random() - 0.5) * 20 - 1; }
        p.setXYZ(i, x, y, z);
      }
      p.needsUpdate = true;
      this.dust.material.opacity = 0.4 + Math.sin(t * 0.8) * 0.08;
    }
    // camera rig breathing + shake (the game owns the camera when camAuto=false)
    if (this.camAuto) {
      const cam = this.camera;
      const bx = Math.sin(t * 0.31) * 0.035;
      if (!this.camBase) this.camBase = cam.position.clone();
      cam.position.set(this.camBase.x + bx, this.camBase.y + Math.sin(t * 0.47 + 1) * 0.022, this.camBase.z);
      if (this.camRig.shake > 0) {
        cam.position.x += (Math.random() - 0.5) * this.camRig.shake;
        cam.position.y += (Math.random() - 0.5) * this.camRig.shake;
        this.camRig.shake *= 0.9;
      }
      cam.lookAt(this.camTarget);
    }
  }

  spinCage(speed) {
    this.cageSpinSpeed = speed;
    this.cageDecel = 0.5;
  }

  /* --------------------------------------------------------------- helpers -- */
  setCardStand(cardMeshGroup) {
    this.cardGroup = cardMeshGroup;
  }
}
