/* Bundles the whole game into one offline HTML file (no server needed). */
const fs = require('fs');
const path = require('path');
const root = __dirname;
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scripts = ['src/vendor/three.min.js', 'src/textures.js', 'src/audio.js', 'src/build3d.js', 'src/ui.js', 'src/main.js'];
scripts.forEach((rel) => {
  const code = fs.readFileSync(path.join(root, rel), 'utf8');
  // NOTE: use a function replacer — minified code contains $& which String.replace
  // would otherwise treat as a back-reference and corrupt the bundle.
  html = html.replace('<script src="' + rel + '"></script>', () => '<script>\n' + code + '\n</script>');
});
html = html.replace('<title>', '<!-- Lucky Lounge Bingo — single file build. Piano-trio jazz is synthesized live. -->\n<title>');
const out = path.join(root, 'LuckyLoungeBingo.html');
fs.writeFileSync(out, html);
console.log('wrote', out, (fs.statSync(out).size / 1024).toFixed(0) + ' KB',
  '| remaining external refs:', (html.match(/src="(?!data:)/g) || []).length);
