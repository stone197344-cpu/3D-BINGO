const puppeteer = require('puppeteer');
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:1280,height:760});
  const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('http://localhost:8123/index.html',{waitUntil:'networkidle2',timeout:60000});
  await new Promise(r=>setTimeout(r,12000));
  const info = await p.evaluate(async ()=>{
    const g = window.game;
    const lights = []; g.lounge.scene.traverse(o=>{ if(o.isLight) lights.push(o.type); });
    const counts = {}; lights.forEach(t=>counts[t]=(counts[t]||0)+1);
    let meshes=0, tris=0; g.lounge.scene.traverse(o=>{ if(o.isMesh){ meshes++; const gg=o.geometry; if(gg&&gg.index) tris+=gg.index.count/3; else if(gg&&gg.attributes.position) tris+=gg.attributes.position.count/3; } });
    // measure real frame time
    const t0 = performance.now(); let frames=0;
    await new Promise(res=>{ let i=0; const tick=()=>{ frames++; if(performance.now()-t0>4000) res(); else requestAnimationFrame(tick); }; requestAnimationFrame(tick); });
    const ms = (performance.now()-t0)/frames;
    return { counts, meshes, tris:Math.round(tris), frameMs: +ms.toFixed(1), gameTime: +g.t.toFixed(1), phase:g.phase, called:g.called.length,
             drawCalls: g.lounge.renderer.info.render.calls, programs: g.lounge.renderer.info.programs.length };
  });
  console.log(JSON.stringify({info, errs},null,2));
  await b.close();
})();
