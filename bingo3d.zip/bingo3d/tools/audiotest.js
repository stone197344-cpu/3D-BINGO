/* Renders the live jazz engine offline and measures the signal it produces,
   so we can prove the trio is audible (and mixes at a sane level). */
const puppeteer = require('puppeteer');
const fs = require('fs');
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio','--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage();
  const errs=[]; p.on('pageerror',e=>errs.push(String(e.message)));
  await p.goto('http://localhost:8123/LuckyLoungeBingo.html?q=low',{waitUntil:'load',timeout:60000});
  await new Promise(r=>setTimeout(r,4000));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,4000));   // let the trio settle in
  const res = await p.evaluate(async () => {
    const g = window.game, a = g.audio;
    const ctx = a.ctx;
    // tap the music bus with an analyser and watch the level over ~3.5 s
    const an = ctx.createAnalyser(); an.fftSize = 2048;
    a.musicBus.connect(an);
    const buf = new Float32Array(an.fftSize);
    let peak = 0, sum = 0, frames = 0, framesWithSignal = 0;
    const t0 = performance.now();
    while (performance.now() - t0 < 3500) {
      an.getFloatTimeDomainData(buf);
      let f = 0;
      for (let i = 0; i < buf.length; i++) { const v = Math.abs(buf[i]); if (v > f) f = v; sum += v * v; }
      frames++;
      if (f > 0.002) framesWithSignal++;
      if (f > peak) peak = f;
      await new Promise(r => setTimeout(r, 40));
    }
    return {
      ctxState: ctx.state, sampleRate: ctx.sampleRate,
      musicBusGain: +a.musicBus.gain.value.toFixed(3),
      playing: a.jazz.playing, tempo: +a.jazz.tempo.toFixed(1), beats: a.jazz.beat,
      pianoCache: a.jazz.pianoCache.size, bassCache: a.jazz.bassCache.size, vibCache: a.jazz.vibCache.size,
      peak: +peak.toFixed(3), rms: +Math.sqrt(sum / (frames * 2048)).toFixed(4),
      framesWithSignal, frames, callerSupported: a.caller.supported, callerVoice: a.caller.voice ? a.caller.voice.name : null
    };
  });
  console.log(JSON.stringify({res, errs}, null, 1));
  await b.close();
})();
