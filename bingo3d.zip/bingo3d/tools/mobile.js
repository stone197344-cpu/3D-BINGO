const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = __dirname + '/../shots';
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:390,height:844,deviceScaleFactor:1,isMobile:true,hasTouch:true});
  const errs=[]; p.on('pageerror',e=>errs.push(String(e.message)));
  await p.goto('http://localhost:8123/?q=low',{waitUntil:'load',timeout:60000});
  await new Promise(r=>setTimeout(r,5000));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,11000));
  await p.screenshot({path: OUT + '/m1-portrait.png'});
  const st = await p.evaluate(()=>{ const g=window.game; return { fov:+g.lounge.camera.fov.toFixed(1), called:g.called.length, fps:Math.round(g._fps||0) }; });
  console.log(JSON.stringify({st, errs}));
  await b.close();
})();
