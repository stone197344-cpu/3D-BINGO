/* Verifies the exact URL the live preview serves (root -> index.html + src/) */
const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = __dirname + '/../shots';
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:1440,height:810});
  const errs=[], failed=[];
  p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
  p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
  p.on('requestfailed',r=>failed.push(r.url()));
  p.on('response',r=>{ if(r.status()>=400) failed.push(r.status()+' '+r.url()); });
  await p.goto('http://localhost:8123/', { waitUntil:'load', timeout:60000 });   // root, as the preview does
  await new Promise(r=>setTimeout(r,5000));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,12000));
  await p.evaluate(()=>window.game.daubAllCalled());
  await new Promise(r=>setTimeout(r,2500));
  const st = await p.evaluate(()=>{ const g=window.game; return {
    mode:g.mode, called:g.called.length, chips:g.playerRig.chips.size,
    ambience:g.audio.ambience.playing, sfxReady:typeof g.audio.sfx.chip === 'function',
    voiceReady:typeof g.audio.caller.say === 'function', noMusicEngine:(g.audio.jazz === undefined),
    quality:g.lounge.quality,
    qualityAutoWorks:typeof g.autoQuality === 'function' }; });
  await p.screenshot({path: OUT + '/preview-boot.png'});
  console.log(JSON.stringify({ st, errs, failed }, null, 1));
  await b.close();
})();
