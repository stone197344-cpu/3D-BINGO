/* final smoke test on the shipped single file */
const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = __dirname + '/../shots';
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:1366,height:768});
  const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
  p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
  await p.goto('http://localhost:8123/LuckyLoungeBingo.html',{waitUntil:'load',timeout:60000});
  await new Promise(r=>setTimeout(r,4500));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,14000));
  await p.evaluate(()=>window.game.daubAllCalled());
  await new Promise(r=>setTimeout(r,3000));
  const st = await p.evaluate(()=>{ const g=window.game; return { called:g.called.length, chips:g.playerRig.chips.size,
    noMusicEngine: typeof window.JazzLounge === 'undefined' && g.audio.jazz === undefined,
    ambience:g.audio.ambience.playing, sfxReady:typeof g.audio.sfx.chip === 'function', voice:typeof g.audio.caller.say === 'function',
    quality:g.lounge.quality, fps:Math.round(g._fps||0) }; });
  await p.screenshot({path: OUT + '/final-check.png'});
  console.log(JSON.stringify({st, errs}));
  await b.close();
})();
