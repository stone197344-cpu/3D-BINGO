/* Headless validation of the audio engine WITHOUT a browser:
   a stub Web Audio API records every node/param call so typos surface here. */
const fs = require('fs');
const calls = [];
const param = (v) => ({
  value: v,
  setValueAtTime: (...a) => calls.push(['setValueAtTime', ...a]),
  linearRampToValueAtTime: (...a) => calls.push(['linearRamp', ...a]),
  exponentialRampToValueAtTime: (...a) => { if (a[1] === 0) throw new Error('exponentialRamp to 0'); calls.push(['expRamp', ...a]); },
  setTargetAtTime: (...a) => calls.push(['setTarget', ...a]),
  cancelScheduledValues: (...a) => calls.push(['cancel', ...a])
});
const node = (type) => ({
  type, connect: () => {}, disconnect: () => {}, start: () => {}, stop: () => {}, addEventListener: () => {},
  gain: param(1), frequency: param(440), Q: param(1), pan: param(0), detune: param(0),
  threshold: param(0), knee: param(0), ratio: param(1), attack: param(0), release: param(0),
  fftSize: 2048, buffer: null, loop: false, playbackRate: param(1), offset: 0, duration: 1
});
const ctx = {
  sampleRate: 44100, currentTime: 0, state: 'running', resume: () => {},
  destination: node('dest'),
  createGain: () => node('gain'),
  createOscillator: () => { const n = node('osc'); n.frequency = param(440); return n; },
  createBiquadFilter: () => node('biquad'),
  createConvolver: () => node('convolver'),
  createDynamicsCompressor: () => node('comp'),
  createStereoPanner: () => node('panner'),
  createBufferSource: () => node('src'),
  createBuffer: (ch, len, sr) => {
    const data = Array.from({ length: ch }, () => new Float32Array(len));
    return { numberOfChannels: ch, length: len, sampleRate: sr, getChannelData: (i) => data[i] };
  }
};
global.window = global;
global.THREE = undefined;
const code = fs.readFileSync(__dirname + '/../src/audio.js', 'utf8');
// class declarations are lexically scoped to the eval, so re-export them
eval(code + '\n;global.Sfx = Sfx; global.Ambience = Ambience; global.Caller = Caller;');

const out = ctx.createGain();
const sfx = new Sfx(ctx, out);
const amb = new Ambience(ctx, out);
const caller = new Caller();
amb.start();
// fire every effect the game uses
sfx.chip(1.0, 0.2); sfx.applause(1, 3); sfx.fanfare(true); sfx.fanfare(false); sfx.coin();
sfx.cageCrank(2, 6, 0.05); sfx.ballDrop(3); sfx.ballRoll(4, 0.5);
sfx.ui('hover'); sfx.ui('click'); sfx.ui('bad'); sfx.ui('ding');
amb.clink(); amb.chatter(); amb.scrape();
for (let i = 0; i < 200; i++) { ctx.currentTime = i * 0.05; if (typeof sfx.ui === 'function') sfx.ui('click'); }
caller.say('B. ... seven!');
setTimeout(() => {
  const counts = calls.reduce((m, c) => (m[c[0]] = (m[c[0]] || 0) + 1, m), {});
  console.log(JSON.stringify({
    ambiencePlaying: amb.playing, schedulerArmed: !!amb.timer,
    callerSpeechSupported: caller.supported, exportedClasses: ['Sfx','Ambience','Caller'],
    musicEnginePresent: typeof JazzLounge !== 'undefined',
    paramCalls: counts
  }, null, 1));
  process.exit(0);
}, 200);
