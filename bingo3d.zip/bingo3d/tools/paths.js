/* Exercises the untested paths: opponent win, false claim, pattern ladder, blackout. */
const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = __dirname + '/../shots';
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:1280,height:720});
  const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
  p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
  await p.goto('http://localhost:8123/LuckyLoungeBingo.html?q=low',{waitUntil:'load',timeout:60000});
  await new Promise(r=>setTimeout(r,4000));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,6000));
  const out = {};

  // 1) FALSE CLAIM: claim with an incomplete card
  const coinsBefore = await p.evaluate(()=>{ window.game.claim(); return window.game.coins; });
  await new Promise(r=>setTimeout(r,600));
  out.falseClaim = await p.evaluate((before)=>({
    coinsDropped: before, toast: document.querySelectorAll('.toast.bad').length > 0,
    roundStillLive: !window.game.roundOver
  }), coinsBefore);
  await p.screenshot({path: OUT + '/p-falseclaim.png'});

  // 2) OPPONENT WIN: hand Rosa a completed card, then let her claim
  await p.evaluate(()=>{
    const g = window.game;
    const op = g.opponents[0];
    g.pattern.groups[0].forEach(([r,c]) => op.daubed.add(r*5+c));
    op.bingoAt = g.t;
    g.queue.push({ at: g.t + 0.4, fn: () => { if (!g.roundOver) g.endRound(op.name); } });
  });
  await new Promise(r=>setTimeout(r,2200));
  out.opponentWin = await p.evaluate(()=>({
    roundOver: window.game.roundOver,
    modalVisible: !document.getElementById('overlay-modal').classList.contains('hide'),
    headline: (document.querySelector('#modalBody h1')||{}).textContent,
    coins: window.game.coins
  }));
  await p.screenshot({path: OUT + '/p-opponent-win.png'});

  // 3) NEXT ROUND LADDER: step through rounds 2..10 and check the pattern names
  const ladder = [];
  for (let i = 0; i < 9; i++) {
    await p.evaluate(()=>{ const el=document.querySelector('#btnNext'); if (el) el.click(); });
    await new Promise(r=>setTimeout(r,700));
    ladder.push(await p.evaluate(()=>({ r: window.game.round, pat: window.game.pattern.name, pot: window.game.pot,
      groups: window.game.pattern.groups.length, cells: window.game.pattern.groups[0].length })));
    // clear any modal the opponents may have triggered, and keep the round moving
    await p.evaluate(()=>{ const g=window.game; if (g.roundOver) { const el=document.querySelector('#btnNext'); if (el) el.click(); } });
    await new Promise(r=>setTimeout(r,400));
  }
  out.ladder = ladder;

  // 4) BLACKOUT sanity: does a full card register as a bingo?
  out.blackout = await p.evaluate(()=>{
    const g = window.game;
    const savePat = g.pattern;
    g.pattern = PATTERNS.blackout;
    const all = new Set(); for (let i=0;i<25;i++) all.add(i);
    const full = progOf(all, g.pattern.groups);
    const nearly = new Set([...all].filter(i => i !== 7));
    const almost = progOf(nearly, g.pattern.groups);
    g.pattern = savePat;
    return { fullDone: full.done, fullBest: full.best, almostDone: almost.done, almostBest: +almost.best.toFixed(3) };
  });

  out.final = await p.evaluate(()=>({ round: window.game.round, pattern: window.game.pattern.name,
    noMusicEngine: window.game.audio.jazz === undefined, ambience: window.game.audio.ambience.playing }));
  await p.screenshot({path: OUT + '/p-late-round.png'});
  console.log(JSON.stringify({out, errs}, null, 1));
  await b.close();
})();
