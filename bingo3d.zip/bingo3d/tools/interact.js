/* Verifies the money path: a real mouse click on the 3D card lays a chip. */
const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = __dirname + '/../shots';
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await puppeteer.launch({ headless:'new', args:['--no-sandbox','--disable-setuid-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--mute-audio'] });
  const p = await b.newPage();
  await p.setViewport({width:1280,height:720});
  const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
  await p.goto('http://localhost:8123/LuckyLoungeBingo.html?q=low',{waitUntil:'load',timeout:60000});
  await new Promise(r=>setTimeout(r,3500));
  await p.click('#btnStart');
  await new Promise(r=>setTimeout(r,20000));            // wait for a few calls
  await p.keyboard.press('2');                           // card camera
  await new Promise(r=>setTimeout(r,3000));
  const target = await p.evaluate(() => {
    const g = window.game;
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
      const n = g.playerRig.numAt(r, c);
      if (n && g.calledSet.has(n) && !g.playerRig.daubed.has(r * 5 + c)) {
        const v = g.playerRig.cellLocal(r, c).applyMatrix4(g.playerRig.group.matrixWorld).project(g.lounge.camera);
        return { r, c, n, x: (v.x + 1) / 2 * window.innerWidth, y: (-v.y + 1) / 2 * window.innerHeight };
      }
    }
    return null;
  });
  let clicked = null;
  if (target) {
    await p.mouse.move(target.x, target.y);
    await p.mouse.down(); await new Promise(r=>setTimeout(r,60)); await p.mouse.up();
    await new Promise(r=>setTimeout(r,900));
    clicked = await p.evaluate((t) => {
      const g = window.game;
      return { daubedCell: g.playerRig.daubed.has(t.r * 5 + t.c), chips: g.playerRig.chips.size, daubs: g.stats.daubs };
    }, target);
  }
  await p.screenshot({path: OUT + '/h-card-click.png'});
  // also verify a bad click (uncalled number) shakes and does not chip
  const bad = await p.evaluate(() => {
    const g = window.game;
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
      const n = g.playerRig.numAt(r, c);
      if (n && !g.calledSet.has(n)) {
        const v = g.playerRig.cellLocal(r, c).applyMatrix4(g.playerRig.group.matrixWorld).project(g.lounge.camera);
        return { r, c, x: (v.x + 1) / 2 * window.innerWidth, y: (-v.y + 1) / 2 * window.innerHeight };
      }
    }
    return null;
  });
  let badRes = null;
  if (bad) {
    await p.mouse.move(bad.x, bad.y); await p.mouse.down(); await new Promise(r=>setTimeout(r,50)); await p.mouse.up();
    await new Promise(r=>setTimeout(r,700));
    badRes = await p.evaluate((t) => {
      const g = window.game;
      return { wronglyDaubed: g.playerRig.daubed.has(t.r * 5 + t.c), toastShown: document.querySelectorAll('.toast.bad').length > 0 };
    }, bad);
  }
  console.log(JSON.stringify({ target: target && { r: target.r, c: target.c, n: target.n }, clicked, badRes, errs }, null, 1));
  await b.close();
})();
